import streamlit as st
import os
import config
from PIL import Image
import base64

def add_logo():
    """Add logo to the sidebar"""
    logo_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 
                            "LOGO", "marioagentic.png")
    
    if os.path.exists(logo_path):
        logo = Image.open(logo_path)
        st.sidebar.image(logo, width=150)
    else:
        st.sidebar.title("AI Media Studio")

def get_css():
    """Return CSS for styling"""
    return """
    <style>
    .sidebar .sidebar-content {
        background-color: #f5f7f9;
    }
    .stButton button {
        width: 100%;
        border-radius: 5px;
        height: 3em;
        background-color: #4285F4;
        color: white;
        font-weight: bold;
    }
    .stButton button:hover {
        background-color: #3b77db;
    }
    .feature-card {
        padding: 20px;
        border-radius: 5px;
        margin-bottom: 10px;
        background-color: #f9f9f9;
        border-left: 5px solid #4285F4;
    }
    .feature-title {
        font-weight: bold;
        color: #4285F4;
    }
    </style>
    """

def create_feature_card(icon, title, description):
    """Create a feature card for the sidebar"""
    return f"""
    <div class="feature-card">
        <div class="feature-title">{icon} {title}</div>
        <div>{description}</div>
    </div>
    """

def create_sidebar():
    """Create the sidebar for the application"""
    st.sidebar.markdown(get_css(), unsafe_allow_html=True)
    
    # Add logo
    add_logo()
    
    # App title
    st.sidebar.title("✨ AI Media Studio")
    st.sidebar.markdown("---")
    
    # Feature selection
    st.sidebar.subheader("Features")
    features = [
        "Chatbot Assistant", 
        "Image Generated", 
        "Video Generated"
    ]
    
    selected_feature = st.sidebar.radio("", features)
    
    # Feature descriptions
    st.sidebar.markdown("---")
    st.sidebar.markdown("### About Features")
    st.sidebar.markdown(
        create_feature_card("🤖", "Chatbot Assistant", 
                         "Chat with AI model to generate text, answer questions, and more."),
        unsafe_allow_html=True
    )
    st.sidebar.markdown(
        create_feature_card("🖼️", "Image Generated", 
                         "Create stunning images with AI Imagen model from text descriptions."),
        unsafe_allow_html=True
    )
    st.sidebar.markdown(
        create_feature_card("🎬", "Video Generated", 
                         "Generate short videos with Veo model from your prompts."),
        unsafe_allow_html=True
    )
    
    return selected_feature