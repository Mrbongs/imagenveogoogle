from typing import Dict, Any, List, Optional, Union, Tuple
import config
from utils.prompt_templates import PromptTemplates
import re
import random
import logging
import streamlit as st
import requests # Added to resolve 'requests is not defined' error
import base64  # Added for video base64 encoding
from tenacity import retry, stop_after_attempt, wait_exponential, before_sleep_log, retry_if_exception_type

class ChatbotAgent:
    """
    Agent class that orchestrates interactions between the user interface and 
    the various AI services (Gemini, Vertex AI Imagen, Vertex AI Veo).
    """
    
    def __init__(self, vertex_service, gemini_service, agent_mode="default"):
        """
        Initialize the chatbot agent with the required services.
        
        Args:
            vertex_service: Service for Vertex AI calls (Imagen and Veo)
            gemini_service: Service for Gemini API calls
            agent_mode: The behavioral mode of the agent (default, creative, professional, etc.)
        """
        self.vertex_service = vertex_service
        self.gemini_service = gemini_service
        self.history = []
        self.agent_mode = agent_mode
        self.system_prompt = PromptTemplates.get_system_prompt(agent_mode)
        self.context = {}  # Store context about the current conversation
        self.max_retries = 2  # Maximum number of retries for API calls
        self.should_retry = True  # Flag for retry logic
        
    def process_chat_message(self, message: str, model_name: Optional[str] = None) -> str:
        """
        Process a chat message using the Gemini service.
        
        Args:
            message: User's input message
            model_name: The Gemini model to use (optional, defaults to config setting)
            
        Returns:
            Generated response from the AI
        """
        # Add user message to history
        self.history.append({"role": "user", "content": message})
        
        # Use the specified model name or default from config
        model = model_name or config.GEMINI_MODEL
        
        # Update context with any detected preferences or topics
        self._update_context(message)
        
        # Determine message type and format appropriately
        prompt_type, confidence = PromptTemplates.detect_prompt_type(message)
        formatted_message = self._format_message_by_type(message, prompt_type, confidence)
        
        # Apply system prompt based on agent mode and detected content
        enhanced_prompt = self._apply_system_prompt(formatted_message or message)
        
        # Get response from Gemini
        response = self.gemini_service.generate_text(
            prompt=enhanced_prompt,
            model_name=model
        )
        
        # Add response to history
        self.history.append({"role": "assistant", "content": response})
        
        return response
    
    def process_chat_streaming(self, message: str, model_name: Optional[str] = None):
        """
        Process a chat message with streaming response using the Gemini service.
        
        Args:
            message: User's input message
            model_name: The Gemini model to use (optional, defaults to config setting)
            
        Returns:
            Generator yielding chunks of the response
        """
        # Add user message to history
        self.history.append({"role": "user", "content": message})
        
        # Use the specified model name or default from config
        model = model_name or config.GEMINI_MODEL
        
        # Update context with any detected preferences or topics
        self._update_context(message)
        
        # Determine message type and format appropriately
        prompt_type, confidence = PromptTemplates.detect_prompt_type(message)
        formatted_message = self._format_message_by_type(message, prompt_type, confidence)
        
        # Apply system prompt based on agent mode and detected content
        enhanced_prompt = self._apply_system_prompt(formatted_message or message)
        
        retries = 0
        full_response = ""
        
        while retries <= self.max_retries:
            try:
                # Stream response from Gemini
                response_stream = self.gemini_service.generate_text_stream(
                    prompt=enhanced_prompt,
                    model_name=model,
                    temperature=self._get_temperature_for_mode()
                )
                
                # Keep track of the full response to add to history later
                full_response = ""
                empty_response = True
                
                # Yield each chunk while building the full response
                for chunk in response_stream:
                    if chunk:
                        empty_response = False
                        full_response += chunk
                        yield chunk
                
                # If we got an empty response but are within retry limits, try again
                if empty_response and retries < self.max_retries:
                    retries += 1
                    yield f"[Retrying due to empty response... ({retries}/{self.max_retries})]"
                    continue
                
                # Add final response to history and exit the retry loop
                self.history.append({"role": "assistant", "content": full_response})
                break
                
            except Exception as e:
                retries += 1
                error_message = f"Error: {str(e)}"
                
                # If we've reached the maximum retries, return the error
                if retries > self.max_retries:
                    full_response = f"I encountered an error while processing your request: {error_message}. Please try again."
                    self.history.append({"role": "assistant", "content": full_response})
                    yield full_response
                    break
                
                # Otherwise yield error info and retry
                yield f"[Encountered an error, retrying ({retries}/{self.max_retries})...]"
                
        # If we somehow broke out of the loop without setting history (shouldn't happen)
        if not full_response and not self.history[-1].get("role") == "assistant":
            full_response = "I'm sorry, I wasn't able to process your request successfully. Please try again with a different question."
            self.history.append({"role": "assistant", "content": full_response})
            yield full_response
    
    def _format_message_by_type(self, message: str, prompt_type: str, confidence: float) -> Optional[str]:
        """
        Format a message based on its detected type.
        
        Args:
            message: User's input message
            prompt_type: Detected prompt type
            confidence: Confidence score for the detection
            
        Returns:
            Formatted message if applicable, None otherwise
        """
        # Only apply formatting if confidence is high enough
        if confidence < 0.6:
            return None
            
        if prompt_type == "image":
            # Extract image parameters if possible
            subject = self._extract_parameter(message, "subject", "main subject")
            style = self._extract_parameter(message, "style", "artistic style")
            lighting = self._extract_parameter(message, "lighting", "lighting conditions")
            perspective = self._extract_parameter(message, "perspective", "camera angle")
            background = self._extract_parameter(message, "background", "background setting")
            mood = self._extract_parameter(message, "mood", "emotional tone")
            details = self._extract_parameter(message, "details", "additional details")
            
            return PromptTemplates.format_image_prompt(
                user_request=message,
                subject=subject,
                style=style,
                lighting=lighting,
                perspective=perspective,
                background=background,
                mood=mood,
                additional_details=details
            )
            
        elif prompt_type == "video":
            # Extract video parameters if possible
            scene = self._extract_parameter(message, "scene", "overall scene")
            camera = self._extract_parameter(message, "camera", "camera movement")
            subjects = self._extract_parameter(message, "subjects", "main subjects")
            actions = self._extract_parameter(message, "actions", "key actions")
            environment = self._extract_parameter(message, "environment", "environment")
            lighting = self._extract_parameter(message, "lighting", "lighting")
            mood = self._extract_parameter(message, "mood", "mood")
            timing = self._extract_parameter(message, "timing", "timing")
            transitions = self._extract_parameter(message, "transitions", "transitions")
            
            return PromptTemplates.format_video_prompt(
                user_request=message,
                scene=scene,
                camera=camera,
                subjects=subjects,
                actions=actions,
                environment=environment,
                lighting=lighting,
                mood=mood,
                timing=timing,
                transitions=transitions
            )
            
        elif prompt_type == "creative" and self.agent_mode in ["creative", "default"]:
            # For creative writing, let's use chain of thought to enhance the creative process
            topic = self._extract_topic(message)
            return PromptTemplates.format_chain_of_thought(
                topic=f"creative writing about {topic}",
                definition=f"The user wants creative content about {topic}",
                analysis="Let's consider the emotional tone, narrative style, and key elements",
                alternatives="We could approach this from different angles and perspectives",
                conclusion="I'll create engaging, original content that captures the essence of the request"
            )
            
        elif prompt_type == "business" and self.agent_mode in ["professional", "default"]:
            # For business documents, we don't format the request but augment with appropriate system prompt
            return None
            
        elif prompt_type == "guide" and self.agent_mode in ["educational", "technical", "default"]:
            # For guides, we don't format the request but augment with appropriate system prompt
            return None
            
        elif prompt_type == "explanation" and self.agent_mode in ["educational", "technical", "default"]:
            # For explanations, we don't format the request but augment with appropriate system prompt
            return None
            
        return None
        
    def _extract_parameter(self, message: str, param_name: str, fallback_name: str) -> str:
        """
        Extract a specific parameter from the message if explicitly mentioned.
        
        Args:
            message: User's input message
            param_name: The parameter name to look for
            fallback_name: Alternative name for the parameter
            
        Returns:
            Extracted parameter value or empty string
        """
        # Look for patterns like "subject: mountain landscape" or "with a dark background"
        patterns = [
            rf"{param_name}:\s*([^,.;]+)",
            rf"{param_name} of\s*([^,.;]+)",
            rf"{fallback_name}:\s*([^,.;]+)",
            rf"{fallback_name} of\s*([^,.;]+)",
            rf"with (?:a|the) ([^,.;]+) {param_name}",
            rf"with (?:a|the) ([^,.;]+) {fallback_name}"
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return match.group(1).strip()
                
        return ""
        
    def _extract_topic(self, message: str) -> str:
        """
        Extract the main topic from a message.
        
        Args:
            message: User's input message
            
        Returns:
            Main topic of the message
        """
        # Look for patterns like "about X" or "regarding X"
        patterns = [
            r"about\s+([^,.;?!]+)",
            r"regarding\s+([^,.;?!]+)",
            r"on\s+([^,.;?!]+)",
            r"write (?:a|an) [^,.;?!]+ about\s+([^,.;?!]+)",
            r"create (?:a|an) [^,.;?!]+ about\s+([^,.;?!]+)"
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return match.group(1).strip()
                
        # Fallback to the message without common verbs at the beginning
        cleaned_message = re.sub(r"^(?:can you|could you|please|help me|i want|i need)[^a-zA-Z0-9]*", "", message, flags=re.IGNORECASE)
        return cleaned_message.strip()
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=60), # Exponential backoff between retries
        retry=retry_if_exception_type((requests.exceptions.RequestException, Exception)), # Retry on network errors and general exceptions
        before_sleep=before_sleep_log(st.session_state.logger if "logger" in st.session_state else logging.getLogger(__name__), logging.WARNING)
    )
    def generate_images(self, prompt: str, num_images: int = 1, aspect_ratio: str = "1:1", seed: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Generates images using Vertex AI service with retry logic.
        Makes a single call to the service to generate all requested images.
        """
        logger = st.session_state.logger if "logger" in st.session_state else logging.getLogger(__name__)
        
        def _generate_with_retry_and_error_handling():
            enhanced_prompt = self._enhance_image_prompt(prompt) # Use original prompt for enhancement
            current_seed = seed if seed is not None else random.randint(0, 2**32 - 1)

            logger.info(f"Attempting to generate {num_images} images with Vertex AI. Seed: {current_seed}, Prompt: {enhanced_prompt}")

            try:
                # Single call to Vertex AI service for all images
                # The `original_prompt` argument is removed from this call
                # The `seed` argument is passed to the service method
                image_results_list = self.vertex_service.generate_images(
                    prompt=enhanced_prompt, # Pass the enhanced prompt to the service
                    num_images=num_images,
                    aspect_ratio=aspect_ratio, 
                    seed=current_seed # Pass the seed to the service
                )

                # Validate the response from the service
                if not isinstance(image_results_list, list):
                    logger.error(f"Vertex AI service returned an unexpected type: {type(image_results_list)}. Expected a list.")
                    return [{"success": False, "error": "Invalid response from image generation service.", "base64": None, "prompt": enhanced_prompt, "original_prompt": prompt, "seed_used": current_seed} for _ in range(num_images)]

                # Ensure the list has the correct number of entries, padding with errors if necessary
                # The service now returns a list of dicts, so we process them directly.
                final_results = []
                for i in range(num_images):
                    if i < len(image_results_list) and isinstance(image_results_list[i], dict):
                        # Add original_prompt to the result from the service for consistency in the agent's return value
                        result_item = image_results_list[i]
                        result_item["original_prompt"] = prompt # Add original prompt for logging/display
                        result_item["prompt"] = result_item.get("prompt_used", enhanced_prompt) # Ensure enhanced prompt is there
                        final_results.append(result_item)
                    else: 
                        logger.warning(f"Image generation for image {i+1} (out of {num_images}) might have failed or was not returned by the service as expected.")
                        final_results.append({
                            "success": False, 
                            "error": "Image data not returned or generation failed for this item.", 
                            "base64": None, 
                            "prompt": enhanced_prompt, 
                            "original_prompt": prompt,
                            "seed_used": current_seed
                        })
                
                return final_results

            except Exception as e:
                logger.error(f"Error during Vertex AI image generation call: {e}", exc_info=True)
                # This exception will be caught by the @retry decorator.
                # If all retries fail, the exception will propagate to the caller (app.py).
                # For robustness, we can also return a list of error dicts here if we want to prevent raw exceptions from reaching app.py's main try-catch
                # However, letting tenacity handle retries and then app.py handle the final error is also a valid pattern.
                # For now, let the exception propagate for tenacity to handle.
                raise # Re-raise the exception for tenacity to handle retries

        # The call to the inner function that actually performs the generation.
        # If this raises an exception after all retries, it will be caught in app.py
        return _generate_with_retry_and_error_handling()

    def generate_video(self, prompt: str, duration: int = 3, 
                      model_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate video using Vertex AI Veo.
        
        Args:
            prompt: Text description of the desired video
            duration: Duration of the video in seconds
            model_id: Specific Veo model ID (optional)
            
        Returns:
            Dictionary with video data and metadata
        """
        # Enhance the video prompt first
        enhanced_prompt = self._enhance_video_prompt(prompt, duration)
        
        # Use the specified model ID or default from config
        model = model_id or config.VEO_MODEL
        
        retries = 0
        while retries <= self.max_retries:
            try:
                # Call Vertex service to generate video
                video_data = self.vertex_service.generate_video(
                    prompt=enhanced_prompt,
                    model_id=model,
                    duration_seconds=duration
                )
                
                # Process the result into a more usable format
                if isinstance(video_data, str) and video_data.startswith("Error:"):
                    # Handle error in video generation
                    return {
                        "success": False,
                        "error": video_data,
                        "base64": None,
                        "video_url": None,
                        "prompt": enhanced_prompt,
                        "original_prompt": prompt,
                        "duration": duration
                    }
                elif isinstance(video_data, list) and len(video_data) > 0:
                    # Process successful video (video_data is a list of video info objects)
                    video_info = video_data[0]  # Take the first video
                    video_uri = video_info.get("video_uri")
                    
                    if video_uri:
                        # Try to download and convert to base64 for display
                        try:
                            # Attempt to download video and convert to base64
                            video_base64 = self._download_video_from_gcs(video_uri)
                            
                            if video_base64:
                                # Successfully downloaded and converted
                                return {
                                    "success": True,
                                    "base64": video_base64,
                                    "video_url": video_uri,
                                    "prompt": enhanced_prompt,
                                    "original_prompt": prompt,
                                    "duration": duration
                                }
                            else:
                                # Download failed, return URL for direct access
                                return {
                                    "success": True,
                                    "base64": None,
                                    "video_url": video_uri,
                                    "prompt": enhanced_prompt,
                                    "original_prompt": prompt,
                                    "duration": duration
                                }
                        except Exception as e:
                            # Download failed, return URL with error info
                            return {
                                "success": True,
                                "base64": None,
                                "video_url": video_uri,
                                "download_error": str(e),
                                "prompt": enhanced_prompt,
                                "original_prompt": prompt,
                                "duration": duration
                            }
                    else:
                        return {
                            "success": False,
                            "error": "No video URI found in the response",
                            "base64": None,
                            "video_url": None,
                            "prompt": enhanced_prompt,
                            "original_prompt": prompt,
                            "duration": duration
                        }
                else:
                    # Unexpected response format
                    return {
                        "success": False,
                        "error": f"Unexpected video data format: {type(video_data)} - {str(video_data)[:200]}",
                        "base64": None,
                        "video_url": None,
                        "prompt": enhanced_prompt,
                        "original_prompt": prompt,
                        "duration": duration
                    }
                    
            except Exception as e:
                retries += 1
                if retries > self.max_retries:
                    # Return error information if we've exhausted retries
                    return {
                        "success": False,
                        "error": f"Failed to generate video after {self.max_retries} attempts: {str(e)}",
                        "base64": None,
                        "prompt": enhanced_prompt,
                        "original_prompt": prompt,
                        "duration": duration
                    }
                
                # Short delay before retry
                import time
                time.sleep(1)
    
    def _enhance_image_prompt(self, prompt: str) -> str:
        """
        Enhance an image prompt for better results.
        
        Args:
            prompt: Basic image description
            
        Returns:
            Enhanced prompt with more details
        """
        # For now, use the Gemini model to enhance the prompt
        enhancement_request = f"""
        Enhance the following image generation prompt with more details to create a better visual result.
        Be specific about style, lighting, perspective, mood, and composition.
        Format your response using these parameters:
        
        Subject: [detailed description of main subject]
        Style: [artistic style, rendering approach]
        Lighting: [lighting conditions and quality]
        Perspective: [camera angle, focal length, viewpoint]
        Background: [setting, environment details]
        Mood: [emotional tone, atmosphere]
        Additional details: [any special elements, effects, or small details to include]
        
        Original prompt: {prompt}
        
        Enhanced prompt:
        """
        
        try:
            enhanced = self.gemini_service.generate_text(enhancement_request)
            
            # Extract just the formatted sections if possible
            if "Subject:" in enhanced and "Style:" in enhanced:
                return enhanced
            else:
                # If the AI didn't follow the format, combine the original prompt with the enhancement
                return f"{prompt} {enhanced}"
        except Exception as e:
            print(f"Error enhancing prompt: {e}")
            return prompt  # Fallback to original prompt
    
    def _enhance_video_prompt(self, prompt: str, duration: int) -> str:
        """
        Enhance a video prompt for better results.
        
        Args:
            prompt: Basic video description
            duration: Duration of the video in seconds
            
        Returns:
            Enhanced prompt with more details
        """
        # For now, use the Gemini model to enhance the prompt
        enhancement_request = f"""
        Enhance the following {duration}-second video generation prompt with more details to create a better visual result.
        Be specific about camera movement, timing, transitions, lighting, and actions.
        Format your response using these parameters:
        
        Scene description: [overall setting and content]
        Camera movement: [how the camera should move during the clip]
        Subjects: [main elements/characters in the scene]
        Actions: [what happens during the sequence]
        Environment: [details about the setting]
        Lighting: [lighting conditions and changes]
        Mood: [emotional tone and atmosphere]
        Timing: [pacing and duration of key moments]
        Transitions: [how scenes should blend if applicable]
        
        Original prompt: {prompt}
        
        Enhanced prompt:
        """
        
        try:
            enhanced = self.gemini_service.generate_text(enhancement_request)
            
            # Extract just the formatted sections if possible
            if "Scene description:" in enhanced and "Camera movement:" in enhanced:
                return enhanced
            else:
                # If the AI didn't follow the format, combine the original prompt with the enhancement
                return f"{prompt} {enhanced}"
        except Exception as e:
            print(f"Error enhancing prompt: {e}")
            return prompt  # Fallback to original prompt
    
    def set_agent_mode(self, mode: str):
        """
        Set the behavioral mode of the agent.
        
        Args:
            mode: The mode to set (default, creative, professional, etc.)
        """
        self.agent_mode = mode
        self.system_prompt = PromptTemplates.get_system_prompt(mode)
    
    def clear_history(self):
        """Clear the conversation history"""
        self.history = []
        
    def _update_context(self, message: str):
        """
        Update the conversation context based on the user's message.
        
        Args:
            message: User's input message
        """
        # Extract topics of interest
        if "interest" in message.lower() or "interested in" in message.lower():
            interests = re.findall(r"interested in ([^,.;?!]+)", message, re.IGNORECASE)
            for interest in interests:
                if "interests" not in self.context:
                    self.context["interests"] = []
                self.context["interests"].append(interest.strip())
        
        # Extract preferences
        if "prefer" in message.lower() or "preference" in message.lower():
            preferences = re.findall(r"prefer ([^,.;?!]+)", message, re.IGNORECASE)
            for preference in preferences:
                if "preferences" not in self.context:
                    self.context["preferences"] = []
                self.context["preferences"].append(preference.strip())
        
        # Extract current task or goal
        if any(word in message.lower() for word in ["help me", "I need to", "I want to", "I'm trying to"]):
            goals = re.findall(r"(?:help me|I need to|I want to|I'm trying to) ([^,.;?!]+)", message, re.IGNORECASE)
            if goals:
                self.context["current_goal"] = goals[0].strip()
    
    def _apply_system_prompt(self, message: str) -> str:
        """
        Apply the appropriate system prompt to the user message based on the agent mode.
        
        Args:
            message: User's message (possibly already formatted)
            
        Returns:
            Enhanced message with system prompt applied
        """
        # Construct enhanced prompt with system instructions
        system_instruction = self.system_prompt
        
        # Add context awareness if we have accumulated context
        context_addition = ""
        if self.context:
            if "interests" in self.context:
                context_addition += f"\nUser has expressed interest in: {', '.join(self.context['interests'])}."
            if "preferences" in self.context:
                context_addition += f"\nUser has preferences for: {', '.join(self.context['preferences'])}."
            if "current_goal" in self.context:
                context_addition += f"\nUser's current goal appears to be: {self.context['current_goal']}."
        
        # Add conversation history context for continuity
        history_context = ""
        if len(self.history) > 0:
            # Include up to the last 3 exchanges for context
            recent_history = self.history[-min(6, len(self.history)):]
            for entry in recent_history:
                role = "User" if entry["role"] == "user" else "Assistant"
                history_context += f"\n{role}: {entry['content']}"
        
        # Combine everything into the final prompt
        enhanced_prompt = f"""System: {system_instruction}{context_addition}

Previous conversation:{history_context}

User's current message: {message}"""

        return enhanced_prompt
    
    def _get_temperature_for_mode(self) -> float:
        """
        Get the appropriate temperature setting based on the agent mode.
        
        Returns:
            Temperature value for the model
        """
        mode_temperatures = {
            "default": 0.2,    # Balanced
            "creative": 0.7,   # Higher temperature for more creativity
            "professional": 0.1, # Lower temperature for more formal and precise results
            "educational": 0.2,  # Moderately low for accuracy but some flexibility
            "technical": 0.1    # Lower temperature for technical precision
        }
        
        return mode_temperatures.get(self.agent_mode, config.GEMINI_TEMPERATURE)
    
    def _download_video_from_gcs(self, gcs_uri: str) -> str:
        """
        Download video from Google Cloud Storage and convert to base64.
        
        Args:
            gcs_uri: Google Cloud Storage URI (gs://bucket/path)
            
        Returns:
            Base64 encoded video data or None if failed
        """
        try:
            import requests
            from google.auth import default
            from google.auth.transport.requests import Request
            
            # Extract bucket and blob path from GCS URI
            if not gcs_uri.startswith('gs://'):
                raise ValueError(f"Invalid GCS URI format: {gcs_uri}")
            
            # Remove 'gs://' prefix and split bucket/path
            path = gcs_uri[5:]  # Remove 'gs://'
            bucket_name, blob_path = path.split('/', 1)
            
            # Get access token for authenticated request
            if hasattr(self.vertex_service, 'gcp_credentials') and self.vertex_service.gcp_credentials:
                credentials = self.vertex_service.gcp_credentials
                credentials.refresh(Request())
                access_token = credentials.token
            else:
                # Fallback to default credentials
                credentials, _ = default()
                credentials.refresh(Request())
                access_token = credentials.token
            
            # Download from GCS using REST API
            download_url = f"https://storage.googleapis.com/storage/v1/b/{bucket_name}/o/{blob_path.replace('/', '%2F')}?alt=media"
            
            headers = {
                'Authorization': f'Bearer {access_token}'
            }
            
            response = requests.get(download_url, headers=headers)
            response.raise_for_status()
            
            # Convert to base64
            video_bytes = response.content
            video_base64 = base64.b64encode(video_bytes).decode('utf-8')
            
            return video_base64
            
        except Exception as e:
            print(f"Failed to download video from GCS: {e}")
            return None
    