import google.generativeai as genai
from typing import Generator, Optional, Dict, Any, List
import config

class GeminiService:
    def __init__(self, api_key: str = None):
        """Initialize Gemini API service with the provided API key."""
        self.api_key = api_key or config.API_KEY
        genai.configure(api_key=self.api_key)
    
    def list_models(self) -> List[str]:
        """List available Gemini models."""
        try:
            models = genai.list_models()
            return [model for model in models if "gemini" in model.name.lower()]
        except Exception as e:
            print(f"Error listing models: {e}")
            return []
    
    def generate_text(self, prompt: str, model_name: str = None, temperature: float = None, max_tokens: int = None) -> str:
        """Generate text response using the Gemini model."""
        try:
            model_name = model_name or config.GEMINI_MODEL
            temperature = temperature or config.GEMINI_TEMPERATURE
            max_tokens = max_tokens or config.GEMINI_MAX_TOKENS
            
            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config={
                    "temperature": temperature,
                    "max_output_tokens": max_tokens,
                }
            )
            response = model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"Error generating text: {e}")
            return f"Error: {e}"
    
    def generate_text_stream(self, prompt: str, model_name: str = None, temperature: float = None, max_tokens: int = None) -> Generator[str, None, None]:
        """Generate streaming text response using the Gemini model."""
        try:
            model_name = model_name or config.GEMINI_MODEL
            temperature = temperature or config.GEMINI_TEMPERATURE
            max_tokens = max_tokens or config.GEMINI_MAX_TOKENS
            
            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config={
                    "temperature": temperature,
                    "max_output_tokens": max_tokens,
                }
            )
            response = model.generate_content(prompt, stream=True)
            for chunk in response:
                if hasattr(chunk, 'text') and chunk.text:
                    yield chunk.text
                elif hasattr(chunk, 'parts') and chunk.parts:
                    for part in chunk.parts:
                        if hasattr(part, 'text') and part.text:
                            yield part.text
        except Exception as e:
            print(f"Error generating streaming text: {e}")
            yield f"Error: {e}"
    
    def chat_session(self, history: list, model_name: str = None, temperature: float = None, max_tokens: int = None) -> str:
        """Process a chat session with history."""
        try:
            model_name = model_name or config.GEMINI_MODEL
            temperature = temperature or config.GEMINI_TEMPERATURE
            max_tokens = max_tokens or config.GEMINI_MAX_TOKENS
            
            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config={
                    "temperature": temperature,
                    "max_output_tokens": max_tokens,
                }
            )
            
            # Convert the chat history to the format expected by Gemini
            chat = model.start_chat(history=[
                {"role": "user" if msg["role"] == "user" else "model", "parts": [msg["content"]]} 
                for msg in history if msg["role"] in ["user", "assistant"]
            ])
            
            # Get last user message
            last_user_msg = next((msg["content"] for msg in reversed(history) if msg["role"] == "user"), "")
            
            response = chat.send_message(last_user_msg)
            return response.text
        except Exception as e:
            print(f"Error in chat session: {e}")
            return f"Error: {e}"

    def chat_session_stream(self, history: list, model_name: str = None, temperature: float = None, max_tokens: int = None) -> Generator[str, None, None]:
        """Process a streaming chat session with history."""
        try:
            model_name = model_name or config.GEMINI_MODEL
            temperature = temperature or config.GEMINI_TEMPERATURE
            max_tokens = max_tokens or config.GEMINI_MAX_TOKENS
            
            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config={
                    "temperature": temperature,
                    "max_output_tokens": max_tokens,
                }
            )
            
            # Convert the chat history to the format expected by Gemini
            chat = model.start_chat(history=[
                {"role": "user" if msg["role"] == "user" else "model", "parts": [msg["content"]]} 
                for msg in history if msg["role"] in ["user", "assistant"]
            ])
            
            # Get last user message
            last_user_msg = next((msg["content"] for msg in reversed(history) if msg["role"] == "user"), "")
            
            response = chat.send_message(last_user_msg, stream=True)
            for chunk in response:
                if hasattr(chunk, 'text') and chunk.text:
                    yield chunk.text
                elif hasattr(chunk, 'parts') and chunk.parts:
                    for part in chunk.parts:
                        if hasattr(part, 'text') and part.text:
                            yield part.text
        except Exception as e:
            print(f"Error in streaming chat session: {e}")
            yield f"Error: {e}"

# Initialize the service
gemini_service = GeminiService()