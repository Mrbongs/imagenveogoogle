import os
import time
from typing import List, Dict, Any, Optional, Union
import base64
import json
import requests
from google.cloud import aiplatform
from google.oauth2 import service_account
import config

class VertexAIService:
    def __init__(self, project_id: str = None, location: str = None, credentials_path: str = None):
        """
        Initialize Vertex AI service with the provided project ID and location.
        """
        self.project_id = project_id or config.PROJECT_ID
        self.location = location or config.REGION
        
        # Use VERTEX_CREDENTIALS specifically for Vertex AI operations
        self.credentials_path = credentials_path or config.VERTEX_CREDENTIALS
        self.gcp_credentials = None

        print(f"Initializing Vertex AI with:")
        print(f"  Project ID: {self.project_id}")
        print(f"  Location: {self.location}")
        print(f"  Credentials path: {self.credentials_path}")
        print(f"  Credentials file exists: {os.path.exists(self.credentials_path)}")

        # Initialize Vertex AI
        try:
            if os.path.exists(self.credentials_path):
                print(f"Loading credentials from: {self.credentials_path}")
                self.gcp_credentials = service_account.Credentials.from_service_account_file(
                    self.credentials_path,
                    scopes=['https://www.googleapis.com/auth/cloud-platform']
                )
                
                # Verify the service account email
                with open(self.credentials_path, 'r') as f:
                    cred_data = json.load(f)
                    print(f"Using service account: {cred_data.get('client_email', 'Unknown')}")
                
                aiplatform.init(
                    project=self.project_id,
                    location=self.location,
                    credentials=self.gcp_credentials
                )
                
                # Test the credentials
                try:
                    # This will refresh the token and validate permissions
                    from google.auth.transport.requests import Request as AuthRequest
                    self.gcp_credentials.refresh(AuthRequest())
                    print("✓ Credentials validated successfully")
                except Exception as cred_error:
                    print(f"⚠️ Warning: Credentials validation failed: {cred_error}")
                
            else:
                print("Credentials file not found, trying default credentials...")
                # Fall back to default credentials
                aiplatform.init(
                    project=self.project_id,
                    location=self.location
                )
                try:
                    import google.auth
                    self.gcp_credentials, _ = google.auth.default(
                        scopes=['https://www.googleapis.com/auth/cloud-platform']
                    )
                    print("✓ Using default credentials")
                except google.auth.exceptions.DefaultCredentialsError as e:
                    print(f"❌ Default credentials not found: {e}")
                    self.gcp_credentials = None
            
            self.initialized = True
            print("✓ Vertex AI initialized successfully")
            
        except Exception as e:
            print(f"❌ Error initializing Vertex AI: {e}")
            self.initialized = False

    def _get_access_token(self) -> Optional[str]:
        """Get access token for REST API calls"""
        if not self.gcp_credentials:
            print("❌ No credentials available for token generation")
            return None
            
        try:
            from google.auth.transport.requests import Request as AuthRequest
            
            # Check if token needs refresh
            if not self.gcp_credentials.valid or self.gcp_credentials.expired:
                print("🔄 Refreshing access token...")
                self.gcp_credentials.refresh(AuthRequest())
            
            token = self.gcp_credentials.token
            if token:
                print("✓ Access token obtained successfully")
                return token
            else:
                print("❌ Token is None after refresh")
                return None
                
        except Exception as e:
            print(f"❌ Error getting access token: {e}")
            return None
    
    def generate_images(self, 
                       prompt: str, 
                       model_id: str = None,
                       num_images: int = 1, 
                       aspect_ratio: str = "1:1",
                       seed: Optional[int] = None,
                       enhance_prompt: bool = True,
                       safety_filter_level: str = "BLOCK_MEDIUM_AND_ABOVE",
                       person_generation: str = "DONT_ALLOW",
                       add_watermark: bool = True) -> List[Dict[str, Any]]:
        """
        Generate images using Vertex AI Imagen 4.0 via REST API.
        
        Args:
            prompt: Text prompt for image generation
            model_id: Vertex AI model ID (defaults to imagen-4.0-generate-preview-05-20)
            num_images: Number of images to generate (1-4)
            aspect_ratio: Aspect ratio ("1:1", "9:16", "16:9", "3:4", "4:3")
            seed: Optional seed for reproducibility
            enhance_prompt: Whether to enhance the prompt automatically
            safety_filter_level: Safety filter level
            person_generation: Person generation setting
            add_watermark: Whether to add SynthID watermark
            
        Returns:
            List of dictionaries, each containing image data or error information.
        """
        if not self.initialized:
            return [{"success": False, "base64": None, "error": "Error: Vertex AI not initialized", "prompt_used": prompt, "seed_used": seed} for _ in range(num_images)]

        access_token = self._get_access_token()
        if not access_token:
            return [{"success": False, "base64": None, "error": "Error: Could not obtain access token for API call.", "prompt_used": prompt, "seed_used": seed} for _ in range(num_images)]

        # Use latest Imagen 4.0 model
        model_name = model_id or "imagen-4.0-generate-preview-05-20"
        
        # Define a maximum value for the seed
        MAX_SEED_VALUE = 2147483647 
        
        # Handle seed and watermark conflict
        actual_seed = None
        use_watermark = add_watermark
        
        if seed is not None:
            actual_seed = seed % (MAX_SEED_VALUE + 1)
            # Disable watermark when seed is provided
            use_watermark = False
            print(f"ℹ️ Seed provided ({actual_seed}), watermark disabled to avoid API conflict")
        
        endpoint_url = f"https://{self.location}-aiplatform.googleapis.com/v1/projects/{self.project_id}/locations/{self.location}/publishers/google/models/{model_name}:predict"

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        # Prepare the request payload for Imagen 4.0
        instances = [{
            "prompt": prompt
        }]

        # Build parameters conditionally to avoid seed/watermark conflict
        parameters = {
            "sampleCount": min(num_images, 4),  # Max 4 images per request
            "aspectRatio": aspect_ratio,
            "enhancePrompt": enhance_prompt,
            "safetyFilterLevel": safety_filter_level,
            "personGeneration": person_generation,
            "addWatermark": use_watermark
        }
        
        # Only add seed if it's provided (watermark will already be disabled above)
        if actual_seed is not None:
            parameters["seed"] = actual_seed

        payload = {
            "instances": instances,
            "parameters": parameters
        }

        try:
            # Add delay to help with quota limits
            time.sleep(1)
            
            response = requests.post(endpoint_url, headers=headers, json=payload)
            response.raise_for_status()
            
            response_data = response.json()
            generated_results = []

            if "predictions" in response_data:
                predictions = response_data["predictions"]
                
                for i, prediction in enumerate(predictions):
                    if "bytesBase64Encoded" in prediction:
                        # Image data is already base64 encoded
                        base64_data = prediction["bytesBase64Encoded"]
                        enhanced_prompt = prediction.get("enhancedPrompt", prompt)
                        
                        generated_results.append({
                            "success": True, 
                            "base64": base64_data, 
                            "error": None, 
                            "prompt_used": prompt,
                            "enhanced_prompt": enhanced_prompt,
                            "seed_used": actual_seed,
                            "watermark_enabled": use_watermark
                        })
                    else:
                        generated_results.append({
                            "success": False, 
                            "base64": None, 
                            "error": f"No image data found in prediction {i}", 
                            "prompt_used": prompt, 
                            "seed_used": actual_seed
                        })

            # Ensure we return a result for each requested image
            while len(generated_results) < num_images:
                generated_results.append({
                    "success": False, 
                    "base64": None, 
                    "error": "Error: Did not generate enough images or API response incomplete.", 
                    "prompt_used": prompt, 
                    "seed_used": actual_seed
                })

            return generated_results[:num_images]

        except requests.exceptions.HTTPError as http_err:
            error_content = http_err.response.text
            error_message = f"HTTP error during image generation: {http_err}. Response: {error_content}"
            print(error_message)
            return [{"success": False, "base64": None, "error": error_message, "prompt_used": prompt, "seed_used": actual_seed} for _ in range(num_images)]
        except Exception as e:
            error_message = f"Error generating images: {str(e)}"
            print(error_message)
            return [{"success": False, "base64": None, "error": error_message, "prompt_used": prompt, "seed_used": actual_seed} for _ in range(num_images)]
    
    def generate_video(self,
                       prompt: str,
                       model_id: str = None,
                       num_videos: int = 1,
                       generate_audio: bool = False,
                       duration_seconds: int = 5) -> Union[List[str], str]:
        """
        Generate video using Vertex AI Veo via REST API.
        
        Args:
            prompt: Text prompt for video generation
            model_id: Vertex AI model ID (defaults to config.VEO_MODEL)
            num_videos: Number of videos to generate (1-2 max)
            generate_audio: Whether to generate audio for the video
            duration_seconds: Duration of the video in seconds (5-10)
            
        Returns:
            Video URLs or error message
        """
        if not self.initialized:
            return "Error: Vertex AI not initialized"

        if not config.VEO_OUTPUT_STORAGE_URI or "YOUR_BUCKET_NAME" in config.VEO_OUTPUT_STORAGE_URI:
            return "Error: VEO_OUTPUT_STORAGE_URI not configured correctly in config.py. Please set it to your GCS bucket URI (e.g., gs://your-bucket-name/output/). Make sure the bucket exists and the service account has write permissions."

        # Validate storage URI format
        if not config.VEO_OUTPUT_STORAGE_URI.startswith("gs://"):
            return f"Error: VEO_OUTPUT_STORAGE_URI must start with 'gs://'. Current value: {config.VEO_OUTPUT_STORAGE_URI}"

        access_token = self._get_access_token()
        if not access_token:
            return "Error: Could not obtain access token for API call."

        # Use Veo model
        model_name = model_id or config.VEO_MODEL
        
        # Correct endpoint URL format for Veo 3.0 long-running prediction
        endpoint_url = f"https://{self.location}-aiplatform.googleapis.com/v1/projects/{self.project_id}/locations/{self.location}/publishers/google/models/{model_name}:predictLongRunning"

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        # Prepare the request payload for Veo according to official documentation
        payload = {
            "instances": [{
                "prompt": prompt
            }],
            "parameters": {
                "storageUri": config.VEO_OUTPUT_STORAGE_URI,
                "sampleCount": str(min(num_videos, 2))  # Use string as per API docs
            }
        }
        
        # Add optional parameters conditionally
        if duration_seconds != 5:
            payload["parameters"]["durationSeconds"] = duration_seconds
            
        if generate_audio:
            payload["parameters"]["generateAudio"] = generate_audio

        # Debug logging
        print(f"🔍 Veo API Request Debug:")
        print(f"   Endpoint URL: {endpoint_url}")
        print(f"   Model name: {model_name}")
        print(f"   Storage URI: {config.VEO_OUTPUT_STORAGE_URI}")
        print(f"   Payload: {json.dumps(payload, indent=2)}")
        print(f"   Headers: {json.dumps({k: v for k, v in headers.items() if k != 'Authorization'}, indent=2)}")

        try:
            # Initial request to start video generation
            initial_response = requests.post(endpoint_url, headers=headers, json=payload)
            
            print(f"🔍 Response Status: {initial_response.status_code}")
            if initial_response.status_code != 200:
                print(f"🔍 Response Text: {initial_response.text}")
                
            initial_response.raise_for_status()
            operation_data = initial_response.json()
            operation_name = operation_data.get("name")

            print(f"🔍 Operation started successfully:")
            print(f"   Operation name: {operation_name}")
            print(f"   Full response: {json.dumps(operation_data, indent=2)}")

            if not operation_name:
                return f"Error: Could not get operation name from initial response: {operation_data}"

            # Poll for completion using the Veo-specific fetchPredictOperation endpoint
            fetch_operation_url = f"https://{self.location}-aiplatform.googleapis.com/v1/projects/{self.project_id}/locations/{self.location}/publishers/google/models/{model_name}:fetchPredictOperation"

            max_polling_attempts = 120  # Increased to 20 minutes for video generation
            for attempt in range(max_polling_attempts):
                time.sleep(10)
                
                # Check operation status using fetchPredictOperation
                fetch_payload = {
                    "operationName": operation_name
                }
                
                print(f"🔍 Polling attempt {attempt + 1}: {fetch_operation_url}")
                print(f"   Operation name: {operation_name}")
                
                op_response = requests.post(fetch_operation_url, headers=headers, json=fetch_payload)
                op_response.raise_for_status()
                op_data = op_response.json()

                if op_data.get("done"):
                    if op_data.get("error"):
                        return f"Error in video generation operation: {op_data['error']}"
                    
                    api_response_content = op_data.get("response", {})
                    if "@type" in api_response_content and "GenerateVideoResponse" in api_response_content["@type"]:
                        videos = api_response_content.get("videos", [])
                        video_uris = []
                        
                        for video in videos:
                            video_uri = video.get("gcsUri")
                            audio_uri = video.get("audioGcsUri") if generate_audio else None
                            
                            if video_uri:
                                video_info = {
                                    "video_uri": video_uri,
                                    "audio_uri": audio_uri,
                                    "has_audio": generate_audio and audio_uri is not None
                                }
                                video_uris.append(video_info)
                        
                        if not video_uris:
                            return f"Error: No video URIs found in completed operation response: {api_response_content}"
                        return video_uris
                    else:
                        return f"Error: Operation completed but response format is unexpected: {api_response_content}"
                
                print(f"Video generation in progress... attempt {attempt + 1}/{max_polling_attempts}")

            return "Error: Video generation timed out after multiple polling attempts."

        except requests.exceptions.HTTPError as http_err:
            error_content = http_err.response.text
            return f"HTTP error during video generation: {http_err}. Response: {error_content}"
        except requests.exceptions.RequestException as req_err:
            return f"Request error during video generation: {req_err}"
        except Exception as e:
            print(f"Unexpected error generating video: {e}")
            return f"Error: An unexpected error occurred: {str(e)}"

# Initialize the service
vertex_service = VertexAIService()