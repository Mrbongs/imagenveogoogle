# PowerShell script to run the Streamlit AI Media Studio application
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "            AI Media Studio - Starting up...           " -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host ""

# Check if Python is installed
try {
    $pythonVersion = (python --version)
    Write-Host "Found Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "Error: Python is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Please install Python 3.9+ and try again." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Check if virtual environment exists, if not create it
if (-not (Test-Path -Path "venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    try {
        python -m venv venv
        Write-Host "Virtual environment created successfully." -ForegroundColor Green
    } catch {
        Write-Host "Error: Failed to create virtual environment." -ForegroundColor Red
        Write-Host $_.Exception.Message
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-Host ""
}

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
try {
    & .\venv\Scripts\Activate.ps1
    Write-Host "Virtual environment activated." -ForegroundColor Green
} catch {
    Write-Host "Error: Failed to activate virtual environment." -ForegroundColor Red
    Write-Host $_.Exception.Message
    Read-Host "Press Enter to exit"
    exit 1
}

# Install or update requirements
Write-Host "Installing/updating requirements..." -ForegroundColor Yellow
try {
    pip install -r requirements.txt
    Write-Host "Dependencies installed successfully." -ForegroundColor Green
} catch {
    Write-Host "Warning: Some dependencies may not have installed correctly." -ForegroundColor Yellow
    Write-Host "The application will attempt to run anyway." -ForegroundColor Yellow
    Write-Host $_.Exception.Message
}
Write-Host ""

# Check for environment variables file
if (-not (Test-Path -Path ".env")) {
    Write-Host "Warning: No .env file found." -ForegroundColor Yellow
    Write-Host "You might need to set up your API keys in config.py." -ForegroundColor Yellow
    Write-Host ""
}

# Run the Streamlit application
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "           Starting Streamlit application...           " -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Access the application at: http://localhost:8501" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop the application" -ForegroundColor Yellow
Write-Host ""

try {
    streamlit run app.py
} catch {
    Write-Host "Error running Streamlit application:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    Read-Host "Press Enter to continue"
}

# Deactivate virtual environment on exit
try {
    deactivate
} catch {
    # Ignore errors on deactivate
}

Write-Host ""
Write-Host "Application closed." -ForegroundColor Yellow
Read-Host "Press Enter to exit"
