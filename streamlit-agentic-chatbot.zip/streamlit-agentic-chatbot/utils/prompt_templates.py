"""
Prompt templates for the chatbot agent.
These templates can be used to guide the AI's responses for different scenarios.
The templates are designed to enhance the capabilities of the AI Media Studio chatbot,
providing specialized responses for different user needs.
"""

class PromptTemplates:
    """Collection of prompt templates for different capabilities."""
    
    # System prompts to define assistant behavior
    SYSTEM_PROMPTS = {
        "default": """You are an AI assistant that helps users with text generation, 
                  image creation, and video creation. You're part of AI Media Studio, a platform
                  that integrates Google's Gemini for text, Vertex AI Imagen for images, and
                  Vertex AI Veo for videos. Provide helpful, accurate, and creative assistance 
                  while guiding users on how to get the most from each feature.""",
        
        "creative": """You are a creative assistant specialized in generating imaginative and original content.
                   Focus on artistic expression, emotional impact, and unique perspectives.
                   Use vivid language, rich metaphors, and think outside conventional boundaries.
                   Provide detailed and evocative descriptions, especially for image and video generation.
                   Help users develop creative writing, artistic concepts, and innovative ideas
                   across text, images, and video mediums.""",
        
        "professional": """You are a professional assistant that helps with business and workplace content.
                       Focus on clarity, structure, and effectiveness in professional communications.
                       Maintain a formal but approachable tone, prioritize actionable insights,
                       and consider strategic implications. Help users develop business communications,
                       strategic analyses, and professional development materials with precision
                       and a results-oriented approach.""",
        
        "educational": """You are an educational assistant that helps users learn and understand complex topics.
                      Break down information into clear, digestible parts using scaffolded learning approaches.
                      Use analogies, examples, and visual descriptions to explain difficult concepts.
                      Focus on accuracy while making information accessible to different learning levels and styles.
                      Structure your responses to build understanding progressively from foundational
                      to more advanced concepts.""",
        
        "technical": """You are a technical assistant specialized in explaining and developing technology solutions.
                    Provide accurate, detailed technical information with practical implementation guidance.
                    Use precise terminology while maintaining clarity, include code examples where helpful,
                    and focus on best practices. Help users understand and solve technical challenges
                    across different technology domains, from programming and data science to
                    system architecture and emerging technologies."""
    }
      # Format templates for different types of requests
    FORMAT_TEMPLATES = {
        "image_enhancement": """I'll help you create a detailed image prompt for the best possible results.
                           
Original user request: {user_request}

Enhanced image generation prompt:
Subject: {subject_description}
Style: {style_description}
Lighting: {lighting}
Perspective: {perspective}
Background/Environment: {background}
Mood/Atmosphere: {mood}
Additional details: {additional_details}

Combined prompt for generation:
{subject_description}, {style_description}, {lighting}, {perspective}, {background}, {mood}, {additional_details}""",
        
        "video_enhancement": """I'll help you create a detailed video prompt for the best possible results.
                           
Original user request: {user_request}

Enhanced video generation prompt:
Scene description: {scene_description}
Camera movement: {camera_movement}
Subjects/Characters: {subjects}
Actions/Movements: {actions}
Environment/Setting: {environment}
Lighting conditions: {lighting}
Mood/Atmosphere: {mood}
Timing/Pacing: {timing}
Transitions: {transitions}

Combined prompt for generation:
{scene_description} {camera_movement} {subjects} {actions} {environment} {lighting} {mood} {timing} {transitions}""",
        
        "chain_of_thought": """Let's think through {topic} step by step:

1. First, let's define what we're looking for:
{definition}

2. Now, let's analyze the key components:
{analysis}

3. Let's consider alternatives and their implications:
{alternatives}

4. Finally, let's synthesize our findings into a conclusion:
{conclusion}""",
        
        "detailed_explanation": """I'll provide a detailed explanation about {topic}.

{context_and_background}

Key concepts:
{key_concepts}

Practical applications:
{applications}

{summary}"""
    }
      # Specialized prompt templates for specific tasks
    TASK_TEMPLATES = {
        "brainstorming": """Let's brainstorm creative ideas about {topic}.
                       
Here are some perspectives to consider:
1. {perspective_1}
2. {perspective_2}
3. {perspective_3}

Initial ideas:
{initial_ideas}

Let's explore these further:
- Idea 1: {idea_1_expansion}
- Idea 2: {idea_2_expansion}
- Idea 3: {idea_3_expansion}

Feel free to select any of these directions or suggest something entirely different.""",
        
        "comparison": """Let's compare {item_1} and {item_2}.

{item_1}:
- Strengths: {strengths_1}
- Weaknesses: {weaknesses_1}
- Key features: {features_1}
- Best use cases: {use_cases_1}

{item_2}:
- Strengths: {strengths_2}
- Weaknesses: {weaknesses_2}
- Key features: {features_2}
- Best use cases: {use_cases_2}

Direct comparison on key factors:
1. Performance: {performance_comparison}
2. Cost-effectiveness: {cost_comparison}
3. Ease of use: {usability_comparison}
4. Flexibility: {flexibility_comparison}

Summary of comparison:
{comparison_summary}

Recommendation based on needs:
{recommendation}""",
        
        "step_by_step_guide": """Step-by-step guide for {task}:

Prerequisites:
{prerequisites}

Materials/Tools needed:
{materials}

Steps:
1. {step_1}
2. {step_2}
3. {step_3}
...

Tips for success:
{tips}

Common pitfalls to avoid:
{pitfalls}

Expected results:
{results}

Troubleshooting common issues:
{troubleshooting}""",
        
        "creative_writing": """Creative writing about {topic} in {style} style:

Setting the scene:
{scene_setting}

Characters/Elements:
{characters}

Plot/Structure:
{plot}

Key themes:
{themes}

Emotional journey:
{emotions}

{creative_content}

Closing thoughts:
{conclusion}""",
        
        "business_document": """[{document_type}: {title}]

Executive Summary:
{executive_summary}

Background:
{background}

Key Points:
1. {point_1}
2. {point_2}
3. {point_3}

Analysis:
{analysis}

Recommendations:
{recommendations}

Next Steps:
{next_steps}

Appendices/References:
{references}"""
    }
    
    @classmethod
    def get_system_prompt(cls, type="default"):
        """Get a system prompt by type."""
        return cls.SYSTEM_PROMPTS.get(type, cls.SYSTEM_PROMPTS["default"])

    @classmethod
    def format_chain_of_thought(cls, topic, definition="", analysis="", alternatives="", conclusion=""):
        """Format a chain of thought reasoning template."""
        return cls.FORMAT_TEMPLATES["chain_of_thought"].format(
            topic=topic,
            definition=definition,
            analysis=analysis,
            alternatives=alternatives,
            conclusion=conclusion
        )
    
    @classmethod
    def format_creative_writing(cls, topic, style="", scene_setting="", characters="", 
                              plot="", themes="", emotions="", creative_content="", conclusion=""):
        """Format a creative writing template."""
        return cls.TASK_TEMPLATES["creative_writing"].format(
            topic=topic,
            style=style,
            scene_setting=scene_setting,
            characters=characters,
            plot=plot,
            themes=themes,
            emotions=emotions,
            creative_content=creative_content,
            conclusion=conclusion
        )
    
    @classmethod
    def format_business_document(cls, document_type, title, executive_summary="", 
                               background="", point_1="", point_2="", point_3="",
                               analysis="", recommendations="", next_steps="", references=""):
        """Format a business document template."""
        return cls.TASK_TEMPLATES["business_document"].format(
            document_type=document_type,
            title=title,
            executive_summary=executive_summary,
            background=background,
            point_1=point_1,
            point_2=point_2,
            point_3=point_3,
            analysis=analysis,
            recommendations=recommendations,
            next_steps=next_steps,
            references=references
        )
    
    @classmethod
    def format_image_prompt(cls, user_request, 
                           subject="", style="", lighting="", 
                           perspective="", background="", mood="", 
                           additional_details=""):
        """Format an enhanced image generation prompt."""
        return cls.FORMAT_TEMPLATES["image_enhancement"].format(
            user_request=user_request,
            subject_description=subject,
            style_description=style,
            lighting=lighting,
            perspective=perspective,
            background=background,
            mood=mood,
            additional_details=additional_details
        )
    
    @classmethod
    def format_video_prompt(cls, user_request,
                           scene="", camera="", subjects="",
                           actions="", environment="", lighting="",
                           mood="", timing="", transitions=""):
        """Format an enhanced video generation prompt."""
        return cls.FORMAT_TEMPLATES["video_enhancement"].format(
            user_request=user_request,
            scene_description=scene,
            camera_movement=camera,
            subjects=subjects,
            actions=actions,
            environment=environment,
            lighting=lighting,
            mood=mood,
            timing=timing,
            transitions=transitions
        )

    @classmethod
    def detect_prompt_type(cls, message):
        """
        Detect the most appropriate prompt template based on message content.
        
        Args:
            message: The user's message
            
        Returns:
            Tuple of (template_type, confidence)
        """
        message_lower = message.lower()
        
        # Check for image generation related content
        if any(term in message_lower for term in ["create image", "generate image", "make image", 
                                                "design image", "picture of", "photo of"]):
            return ("image", 0.9)
            
        # Check for video generation related content
        elif any(term in message_lower for term in ["create video", "generate video", "make video", 
                                                 "animate", "animation of", "video showing"]):
            return ("video", 0.9)
            
        # Check for business document content
        elif any(term in message_lower for term in ["business plan", "proposal", "report", 
                                                 "analysis", "strategy", "executive summary"]):
            return ("business", 0.7)
            
        # Check for creative writing
        elif any(term in message_lower for term in ["story", "poem", "creative", "fiction", 
                                                "narrative", "write a", "compose a"]):
            return ("creative", 0.7)
            
        # Check for step-by-step guides
        elif any(term in message_lower for term in ["how to", "steps to", "guide for", 
                                                 "tutorial", "instructions", "explain how"]):
            return ("guide", 0.7)
            
        # Check for explanations
        elif any(term in message_lower for term in ["explain", "what is", "how does", 
                                                "describe", "define", "clarify"]):
            return ("explanation", 0.6)
            
        # Default to general conversation
        return ("general", 0.5)

# Example use cases:
"""
# System prompt examples
system_prompt_creative = PromptTemplates.get_system_prompt("creative")
system_prompt_professional = PromptTemplates.get_system_prompt("professional")

# Enhanced image prompt example
enhanced_image_prompt = PromptTemplates.format_image_prompt(
    user_request="Make a futuristic city picture",
    subject="A gleaming futuristic metropolis with towering skyscrapers and flying vehicles",
    style="Digital concept art with detailed architectural elements",
    lighting="Dramatic sunset with neon lighting accents illuminating the buildings",
    perspective="Aerial view showing the city sprawl with focal points on key structures",
    background="Gradient sky transitioning from orange to deep blue with scattered clouds",
    mood="Awe-inspiring and optimistic vision of future urban development",
    additional_details="Small details of daily life like pedestrians on elevated walkways and vertical gardens on building facades"
)

# Enhanced video prompt example
enhanced_video_prompt = PromptTemplates.format_video_prompt(
    user_request="Create a nature timelapse video",
    scene="A mountain valley with a clear stream and diverse vegetation",
    camera="Slowly rising drone shot that gradually reveals more of the landscape",
    subjects="The flowing stream as the main subject with surrounding trees and wildlife",
    actions="Cloud shadows moving across the terrain, water flowing, possible wildlife movement",
    environment="Pristine wilderness with mountains in the background",
    lighting="The progression from early morning golden light to midday sunshine",
    mood="Serene, peaceful, awe-inspiring natural beauty",
    timing="Gradual pacing with the first half focused on details, second half revealing the grand landscape",
    transitions="Smooth continuous movement without cuts"
)

# Chain of thought example
reasoning_prompt = PromptTemplates.format_chain_of_thought(
    topic="the environmental impact of cloud computing",
    definition="Cloud computing involves data centers that consume electricity and resources",
    analysis="Key factors include energy consumption, cooling requirements, hardware lifecycle",
    alternatives="On-premises vs. cloud-based solutions, renewable vs. traditional energy sources",
    conclusion="While cloud computing centralizes resource usage which can be more efficient, the growing demand presents significant challenges requiring sustainable approaches"
)

# Business document example
business_proposal = PromptTemplates.format_business_document(
    document_type="Proposal",
    title="AI-Powered Customer Service Enhancement Initiative",
    executive_summary="A strategic plan to implement AI chatbots to improve customer service efficiency while reducing costs",
    background="Current customer service operations face scalability challenges with increasing demand",
    point_1="Implementation of AI chatbots for handling 70% of routine inquiries",
    point_2="Integration with existing CRM systems for seamless customer experience",
    point_3="Phased rollout approach with continuous improvement feedback loops",
    analysis="Cost-benefit analysis shows 35% reduction in per-interaction costs while improving 24/7 availability",
    recommendations="Proceed with pilot program focused on the 10 most common customer inquiries",
    next_steps="Form implementation team and develop detailed 90-day rollout plan",
    references="Industry benchmarks and preliminary vendor evaluations attached"
)

# Detecting prompt type
message = "Can you help me write a story about time travel?"
template_type, confidence = PromptTemplates.detect_prompt_type(message)
# Returns: ("creative", 0.7)
"""
