import streamlit as st
import base64
from PIL import Image
import io
import os
import time
from datetime import datetime

def validate_input(user_input):
    """Validate that user input is not empty"""
    if not user_input or len(user_input.strip()) == 0:
        raise ValueError("Input cannot be empty.")
    return user_input.strip()

def format_response(response):
    """Format response for display"""
    if isinstance(response, dict):
        return response.get('message', 'No message found.')
    return str(response)

def log_interaction(user_input, bot_response):
    """Log user and bot interactions to a file"""
    with open('interaction_log.txt', 'a') as log_file:
        log_file.write(f"User: {user_input}\nBot: {bot_response}\n\n")

def get_current_time():
    """Get formatted current time"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def add_bg_from_url(url):
    """Add background image from URL"""
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("{url}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

def local_css(file_name):
    """Load local CSS"""
    try:
        with open(file_name) as f:
            st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)
    except Exception as e:
        print(f"Error loading CSS: {e}")

def img_to_base64(img_path):
    """Convert image to base64 for embedding in HTML"""
    try:
        with open(img_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode('utf-8')
    except Exception as e:
        print(f"Error converting image to base64: {e}")
        return ""

def image_resize(image, width=None, height=None):
    """Resize an image while maintaining aspect ratio"""
    try:
        # Clone the image to avoid modifying the original
        img = image.copy()
        
        # Calculate new dimensions
        if width and height:
            max_size = (width, height)
            img.thumbnail(max_size)
        elif width:
            w_percent = (width / float(img.size[0]))
            h_size = int(float(img.size[1]) * float(w_percent))
            img = img.resize((width, h_size), Image.LANCZOS)
        elif height:
            h_percent = (height / float(img.size[1]))
            w_size = int(float(img.size[0]) * float(h_percent))
            img = img.resize((w_size, height), Image.LANCZOS)
            
        return img
    except Exception as e:
        print(f"Error resizing image: {e}")
        return image

def create_download_link(file_content, filename, link_text="Download"):
    """Create a download link for file content"""
    b64 = base64.b64encode(file_content).decode()
    href = f'<a href="data:file/txt;base64,{b64}" download="{filename}">{link_text}</a>'
    return href

def get_custom_theme():
    """Get custom theme CSS"""
    return """
    <style>
    /* General app styling */
    .main {
        background-color: #f9f9f9;
    }
    
    /* Header styling */
    h1, h2, h3 {
        color: #4285F4 !important;
        font-family: 'Google Sans', sans-serif;
    }
    
    /* Input fields */
    .stTextInput input, .stTextArea textarea {
        border-radius: 8px;
        border: 1px solid #dadce0;
    }
    
    /* Cards */
    .card {
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 1px 2px 0 rgba(60,64,67,0.3), 0 1px 3px 1px rgba(60,64,67,0.15);
        margin: 10px 0;
        background-color: white;
    }
    
    /* Chat bubbles */
    .user-bubble {
        background-color: #E8F0FE;
        padding: 12px 16px;
        border-radius: 18px 18px 18px 0;
        margin: 8px 0;
        display: inline-block;
        max-width: 80%;
    }
    
    .bot-bubble {
        background-color: #F1F3F4;
        padding: 12px 16px;
        border-radius: 18px 18px 0 18px;
        margin: 8px 0;
        display: inline-block;
        max-width: 80%;
    }
    
    /* Image gallery */
    .image-gallery {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }
    
    .image-card {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    
    /* Progress indicators */
    .progress-bar {
        height: 4px;
        background-color: #4285F4;
        animation: progressAnimation 2s infinite;
    }
    
    @keyframes progressAnimation {
        0% { width: 0%; }
        50% { width: 50%; }
        100% { width: 100%; }
    }
    </style>
    """