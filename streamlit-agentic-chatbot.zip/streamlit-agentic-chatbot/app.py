import streamlit as st
import base64
import os
import random
import time
import io
from PIL import Image

# Import configuration
try:
    import config  # Added import config
except ImportError:
    st.error("Failed to import config.py. Make sure it's in the same directory as app.py.")
    st.stop()

# Import UI components and services
from ui.sidebar import create_sidebar
from utils.helpers import get_custom_theme, validate_input, add_bg_from_url
from services.gemini_service import gemini_service
from services.vertex_service import vertex_service
from agents.chatbot_agent import ChatbotAgent

# Initialize ChatbotAgent
chatbot_agent = ChatbotAgent(vertex_service, gemini_service, agent_mode="default")

# Custom UI components
def render_chatbot_page():
    """Render the Gemini chatbot interface"""
    # Apply card-like style to the content
    st.markdown("""
    <div style="background-color: white; padding: 20px; border-radius: 10px; 
                box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
        <h2 style="color: #4285F4; margin-bottom: 20px;">🤖 AI Assistant</h2>
        <p style="color: #5f6368; margin-bottom: 20px;">
            Your AI assistant powered by Google's Gemini model. Ask questions, get creative content,
            or have a conversation!
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Chat interface
    st.markdown("<br>", unsafe_allow_html=True)  # Add some space
    
    # Agent mode info
    if "agent_mode" in st.session_state:
        current_mode = st.session_state.agent_mode
        mode_descriptions = {
            "default": "Balanced approach providing general assistance across all creative and informational tasks.",
            "creative": "Enhanced creativity mode focusing on original, artistic, and emotionally impactful content.",
            "professional": "Business-oriented mode emphasizing clarity, structure, and professional communication.",
            "educational": "Teaching mode breaking down complex topics with clear explanations and examples.",
            "technical": "Technical mode providing detailed, accurate information with implementation guidance."
        }
        
        with st.expander("ℹ️ Current AI Assistant Mode", expanded=False):
            mode_display_name = {
                "default": "Balanced Mode",
                "creative": "Creative Mode",
                "professional": "Professional Mode", 
                "educational": "Educational Mode",
                "technical": "Technical Mode"
            }.get(current_mode, "Default Mode")
            
            st.markdown(f"""
            <div style="background-color: #E8F0FE; padding: 10px; border-radius: 10px; margin-bottom: 10px;">
                <strong>Currently using:</strong> {mode_display_name}
            </div>
            <p>{mode_descriptions.get(current_mode, "")}</p>
            <p><em>Your AI responses will be tailored according to this mode. You can change the mode in the sidebar.</em></p>
            """, unsafe_allow_html=True)
    
    # Model selection box at the top
    if hasattr(config, 'LLM_CONFIGS'):
        models = list(config.LLM_CONFIGS.keys())
        default_index = models.index(config.DEFAULT_LLM) if config.DEFAULT_LLM in models else 0
        selected_model = st.selectbox("Select Gemini Model:", models, index=default_index)
        model_name = config.LLM_CONFIGS[selected_model]["model_name"]
    else:
        selected_model = "Default"
        model_name = config.GEMINI_MODEL
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = [
            {"role": "assistant", "content": f"Hi there!, How can I help you today?"}
        ]

    # Display chat messages from history
    for i, message in enumerate(st.session_state.messages):
        role_icon = "👤" if message["role"] == "user" else "🤖"
        
        if message["role"] == "user":
            # User message styling
            with st.chat_message("user", avatar=role_icon):
                st.markdown(f"<div style='background-color: #E8F0FE; padding: 10px; border-radius: 10px;'>{message['content']}</div>", 
                           unsafe_allow_html=True)
        else:
            # Assistant message styling
            with st.chat_message("assistant", avatar=role_icon):
                st.markdown(f"<div style='background-color: #F8F9FA; padding: 10px; border-radius: 10px;'>{message['content']}</div>", 
                           unsafe_allow_html=True)

    # Accept user input and process it
    if prompt := st.chat_input("Ask me anything..."):
        # Validate input
        try:
            prompt = validate_input(prompt)
            
            # Add user message to history
            st.session_state.messages.append({"role": "user", "content": prompt})
            
            # Display user message
            with st.chat_message("user", avatar="👤"):
                st.markdown(f"<div style='background-color: #E8F0FE; padding: 10px; border-radius: 10px;'>{prompt}</div>", 
                           unsafe_allow_html=True)
            
            # Generate and display assistant response
            with st.chat_message("assistant", avatar="🤖"):
                thinking_placeholder = st.empty()
                mode_display = st.session_state.get("agent_mode", "default").capitalize()
                
                full_response = "" # Initialize full_response here
                try:
                    if config.API_KEY and not config.API_KEY.startswith("your_"):
                        thinking_placeholder.markdown(
                            f"""<div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <div style="background-color: #F8F9FA; padding: 10px; border-radius: 10px; color: #5f6368;">
                                    Thinking<span class="dots">...</span>
                                </div>
                                <div style="background-color: #E8F0FE; padding: 5px 10px; border-radius: 10px; color: #4285F4; font-size: 12px;">
                                    {mode_display}
                                </div>
                            </div>
                            <style>
                            .dots {{ animation: dots 1.5s steps(5, end) infinite; }}
                            @keyframes dots {{
                                0%, 20% {{ content: ""; }}
                                40% {{ content: "."; }}
                                60% {{ content: ".."; }}
                                80% {{ content: "..."; }}
                                100% {{ content: "..."; }}
                            }}
                            </style>""", unsafe_allow_html=True)
                        
                        # Process chat with streaming
                        response_generator = chatbot_agent.process_chat_streaming(prompt) # Removed thinking_placeholder from args
                        
                        # Iterate through the generator and display chunks
                        full_response_content = ""
                        # Use a new placeholder for the streaming response itself
                        response_placeholder = st.empty() 
                        for chunk in response_generator:
                            full_response_content += chunk
                            response_placeholder.markdown(
                                f"<div style='background-color: #F8F9FA; padding: 10px; border-radius: 10px;'>{full_response_content}</div>", 
                                unsafe_allow_html=True
                            )
                        
                        thinking_placeholder.empty() # Clear the "Thinking..." message
                        full_response = full_response_content # Assign the streamed content to full_response

                    else:
                        # Simulate response with delay if API key is not available
                        time.sleep(1)
                        thinking_placeholder.empty()
                        
                        simulated_responses = [
                            f"I'd love to help with that! However, I notice that a valid API key hasn't been configured. To enable my full capabilities, please update the API_KEY in the config.py file with your Gemini API key.",
                            f"That's an interesting question! For me to provide a proper response, you'll need to configure your Gemini API key in the config.py file.",
                            f"I'm designed to assist with questions like this, but I need a valid API key to access the Gemini model. Please update your configuration to enable this feature."
                        ]
                        
                        full_response = random.choice(simulated_responses)
                        
                        # Simulate typing (already displayed if API key is missing, this is for the history)
                        # The actual display for simulated response is handled by the markdown below if needed,
                        # but the main point here is to set full_response for history.
                        # For consistency, we can ensure the simulated response is also displayed via the placeholder
                        # if we want to unify the display logic, but the current structure has a separate markdown for it.
                        # For now, just ensuring full_response is set for history is key.
                        response_placeholder = st.empty() # Ensure placeholder exists for this path too
                        response_placeholder.markdown(
                            f"<div style='background-color: #F8F9FA; padding: 10px; border-radius: 10px;'>{full_response}</div>", 
                            unsafe_allow_html=True)

                except Exception as e:
                    thinking_placeholder.empty()
                    full_response = f"Sorry, I encountered an error: {str(e)}"
                    # Display error message in the chat
                    response_placeholder = st.empty() # Ensure placeholder exists
                    response_placeholder.markdown(
                        f"<div style='background-color: #FFE6E6; padding: 10px; border-radius: 10px;'>{full_response}</div>", 
                        unsafe_allow_html=True
                    )
                
                # Add assistant response to history if it's not empty
                if full_response: # Check if full_response has content
                    st.session_state.messages.append({"role": "assistant", "content": full_response})
        
        except ValueError as e:
            st.error(str(e))

def render_image_generation_page():
    """Render the Vertex AI Imagen interface"""
    # Apply card-like style to the content
    st.markdown("""
    <div style="background-color: white; padding: 20px; border-radius: 10px; 
                box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
        <h2 style="color: #4285F4; margin-bottom: 20px;">🖼️ AI Image Generate</h2>
        <p style="color: #5f6368; margin-bottom: 20px;">
            Create beautiful images with Google's Imagen 4 Version
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Handle quota exceeded error for image generation and show a helpful message with mock images
    def handle_quota_exceeded_error(prompt, num_images, aspect_ratio):
        st.warning("""
        📊 **API Quota Exceeded**
        
        The Google Cloud Vertex AI quota for image generation has been reached. This typically happens when:
        - Too many requests are made in a short period
        - The project's quota limit has been reached
        
        **Solutions:**
        1. Wait a few minutes and try again
        2. Reduce the number of images requested
        3. Request a quota increase in Google Cloud Console
        
        Showing placeholder images instead.
        """)
        
        # Display placeholder images
        st.markdown('<p style="font-size: 18px; font-weight: 500; margin: 20px 0 10px 0;">Placeholder Images</p>', 
                    unsafe_allow_html=True)
        
        # Create image gallery with placeholder images
        cols = st.columns(min(num_images, 2))
        for i in range(num_images):
            col_idx = i % 2
            with cols[col_idx]:
                # Set dimensions based on aspect ratio
                width, height = (512, 512)
                if aspect_ratio == "16:9":
                    width, height = (512, 288)
                elif aspect_ratio == "9:16":
                    width, height = (288, 512)
                elif aspect_ratio == "4:3":
                    width, height = (512, 384)
                elif aspect_ratio == "3:4":
                    width, height = (384, 512)
                    
                # Display placeholder with prompt summary
                placeholder_url = f"https://via.placeholder.com/{width}x{height}.png?text=Quota+Exceeded"
                st.image(placeholder_url, caption=f"Placeholder {i+1}", use_container_width=True)
                
                # Show prompt that would have been used (as simple text)
                truncated_prompt = prompt[:50] + ('...' if len(prompt) > 50 else '')
                st.caption(f"**Original prompt:** {truncated_prompt}")
        
        # Info about increasing quota (moved outside the loop)
        st.markdown("---")
        st.markdown("### 📈 How to increase quota")
        st.markdown("""
        1. Go to [Google Cloud Console](https://console.cloud.google.com/)
        2. Navigate to APIs & Services > Quotas & System Limits
        3. Find "Vertex AI API - Image Generation requests per minute"
        4. Click "Edit Quotas" and follow the request process
        """)
    
    st.markdown("<br>", unsafe_allow_html=True)  # Add some space
    
    # Prompt input with styling
    st.markdown('<p style="font-size: 18px; font-weight: 500; margin-bottom: 10px;">What would you like to create?</p>', 
                unsafe_allow_html=True)
    
    prompt = st.text_area(
        "Describe the image you want to generate:",
        placeholder="Example: A serene mountain landscape at sunset with a lake reflecting the pink and orange sky",
        help="Be descriptive for best results. Include details about style, mood, colors, etc.",
        height=100,
        key="imagen_prompt",
        label_visibility="collapsed"
    )
    
    # Generation options
    st.markdown('<p style="font-size: 16px; font-weight: 500; margin: 15px 0 10px 0;">Generation Options</p>', 
                unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        num_images = st.slider("Number of images:", 1, 8, 2, help="Select number of images (1-8). Imagen models typically support up to 8.", key="imagen_num") # MODIFIED
    with col2:
        aspect_ratio = st.selectbox("Aspect ratio:", ["1:1", "16:9", "9:16", "4:3", "3:4"], index=0, key="imagen_aspect")
    
    st.caption("Note: AI model usage is subject to API quotas (e.g., requests per minute). Please be mindful, especially with multiple images or frequent requests.") # ADDED

    # Initialize session state for enhanced prompt display
    if "show_enhanced_image_prompt_structure" not in st.session_state:
        st.session_state.show_enhanced_image_prompt_structure = False
    if "enhanced_image_prompt_content" not in st.session_state:
        st.session_state.enhanced_image_prompt_content = None

    # Add prompt enhancement feature
    with st.expander("🔍 Enhance your prompt (optional)", expanded=False):
        st.markdown("""
        <p style="color: #5f6368; font-size: 14px;">
        Let AI help you enhance your prompt with more details for better results. 
        This will add specific details about style, lighting, perspective, and more.
        </p>
        """, unsafe_allow_html=True)
        
        enhance_col, _ = st.columns([1, 3])
        with enhance_col:
            enhance_button = st.button(
                "🪄 Enhance Prompt", 
                key="enhance_imagen_prompt", # Keep original key
                use_container_width=True
            )
        
        if enhance_button and prompt:
            with st.spinner("Enhancing your prompt..."):
                try:
                    # Use the agent's enhancement method
                    enhanced_prompt = chatbot_agent._enhance_image_prompt(prompt)
                    
                    # Update the prompt field with the enhanced version
                    st.session_state.imagen_prompt = enhanced_prompt
                    st.success("Prompt enhanced! The text area has been updated.")
                    
                    # Prepare content for the separate expander
                    sections = {}
                    current_section = None
                    if "Subject:" in enhanced_prompt:
                        for line in enhanced_prompt.split('\\n'):
                            if ":" in line and line.split(":")[0].strip() in ["Subject", "Style", "Lighting", 
                                                                             "Perspective", "Background", "Mood", 
                                                                             "Additional details"]:
                                current_section = line.split(":")[0].strip()
                                sections[current_section] = line.split(":", 1)[1].strip()
                            elif current_section and line.strip():
                                sections[current_section] += " " + line.strip()
                        st.session_state.enhanced_image_prompt_content = sections
                    else:
                        st.session_state.enhanced_image_prompt_content = enhanced_prompt
                    
                    st.session_state.show_enhanced_image_prompt_structure = True
                    st.info("To use the original prompt instead, simply edit the text area. View enhanced details below.")
                except Exception as e:
                    st.error(f"Failed to enhance prompt: {str(e)}")
                    st.session_state.show_enhanced_image_prompt_structure = False # Reset on error
        elif enhance_button and not prompt:
            st.warning("Please enter a prompt first before enhancing.")
            st.session_state.show_enhanced_image_prompt_structure = False # Reset

    # Display enhanced prompt structure if available (moved outside the above expander)
    if st.session_state.get("show_enhanced_image_prompt_structure", False):
        st.markdown("<br>", unsafe_allow_html=True)  # Add some space
        st.markdown("<h3>Enhanced Prompt Details</h3>", unsafe_allow_html=True)
        if isinstance(st.session_state.enhanced_image_prompt_content, dict):
            for section, content in st.session_state.enhanced_image_prompt_content.items():
                st.markdown(f"<strong>{section}:</strong> {content}", unsafe_allow_html=True)
        else:
            st.markdown(st.session_state.enhanced_image_prompt_content, unsafe_allow_html=True)
    
    # Generate button with styling
    generate_col, _ = st.columns([1, 3])
    with generate_col:
        generate_button = st.button(
            "🎨 Generate Images", 
            type="primary",
            use_container_width=True,
            key="imagen_generate"
        )
    
    # Handle image generation
    if generate_button:
        if not prompt or prompt.strip() == "":
            st.error("Please enter a description for the image you want to generate.")
        else:
            # Show progress
            with st.status("Generating your images...", expanded=True) as status:
                st.write("Interpreting your prompt...")
                time.sleep(0.5)
                st.write("Crafting visuals...")
                time.sleep(0.5)
                st.write("Almost done...")
                time.sleep(0.5)
                
                try:
                    # Check if Vertex AI service is properly configured
                    if hasattr(vertex_service, 'initialized') and vertex_service.initialized:
                        # Call Vertex AI service via the agent
                        images = chatbot_agent.generate_images(
                            prompt=prompt,
                            num_images=num_images,
                            aspect_ratio=aspect_ratio
                        )
                        
                        status.update(label="Images generated successfully!", state="complete")
                        
                        # Display images
                        st.markdown('<p style="font-size: 18px; font-weight: 500; margin: 20px 0 10px 0;">Generated Images</p>', 
                                   unsafe_allow_html=True)
                        
                        # Determine number of columns for the gallery
                        num_display_columns = 1
                        if num_images > 1:
                            num_display_columns = min(num_images, 3) # Use 1 col for 1 image, up to 3 cols for more

                        cols = st.columns(num_display_columns) # MODIFIED
                        for i, image_data in enumerate(images):
                            col_idx = i % num_display_columns # MODIFIED
                            with cols[col_idx]:
                                if image_data["success"]:
                                    # Display base64 image
                                    try:
                                        # Convert base64 to image for display
                                        image_bytes = base64.b64decode(image_data["base64"])
                                        image = Image.open(io.BytesIO(image_bytes))
                                        st.image(image, caption=f"Generated Image {i+1}", use_container_width=True)
                                        
                                        # Show prompts used (as simple text to avoid expander nesting)
                                        st.caption(f"**Original:** {image_data['original_prompt'][:50]}{'...' if len(image_data['original_prompt']) > 50 else ''}")
                                        st.caption(f"**Enhanced:** {image_data['prompt'][:50]}{'...' if len(image_data['prompt']) > 50 else ''}")
                                        
                                        # Add download button
                                        st.download_button(
                                            label="Download Image",
                                            data=image_bytes,
                                            file_name=f"generated_image_{i+1}.png",
                                            mime="image/png"
                                        )
                                    except Exception as e:
                                        st.error(f"Error displaying image: {str(e)}")
                                else:
                                    # Display error message
                                    st.error(f"Failed to generate image: {image_data.get('error', 'Unknown error')}")
                                    st.markdown(f"<p style='font-size: 12px; color: #5f6368;'>Prompt: {prompt[:50]}{'...' if len(prompt) > 50 else ''}</p>", 
                                               unsafe_allow_html=True)
                    else:
                        # Simulation for demo purposes
                        status.update(label="Showing sample images (Vertex AI not configured)", state="complete")
                        
                        # Display placeholder images
                        st.markdown('<p style="font-size: 18px; font-weight: 500; margin: 20px 0 10px 0;">Sample Images</p>', 
                                   unsafe_allow_html=True)
                        
                        # Create image gallery with placeholder images
                        cols = st.columns(min(num_images, 2))
                        for i in range(num_images):
                            col_idx = i % 2
                            with cols[col_idx]:
                                width, height = (512, 512)
                                if aspect_ratio == "16:9":
                                    width, height = (512, 288)
                                elif aspect_ratio == "9:16":
                                    width, height = (288, 512)
                                placeholder_url = f"https://via.placeholder.com/{width}x{height}.png?text=Sample+Image+{i+1}"
                                st.image(placeholder_url, caption=f"Sample Image {i+1}", use_container_width=True)
                                st.markdown(f"<p style='font-size: 12px; color: #5f6368;'>Prompt: {prompt[:50]}{'...' if len(prompt) > 50 else ''}</p>", 
                                           unsafe_allow_html=True)
                                st.download_button(
                                    label="Download Image",
                                    data=b"Placeholder binary data", 
                                    file_name=f"sample_image_{i+1}.png",
                                    mime="image/png"
                                )
                except Exception as e:
                    error_message = str(e)
                    status.update(label=f"Error: {error_message}", state="error")
                    
                    # Check if this is a quota exceeded error
                    if "429 Quota exceeded" in error_message and "imagegeneration" in error_message:
                        handle_quota_exceeded_error(prompt, num_images, aspect_ratio)
                    else:
                        # Handle other errors as before
                        st.error(f"Failed to generate images: {error_message}")

def render_video_generation_page():
    """Render the Vertex AI Veo interface"""
    # Apply card-like style to the content
    st.markdown("""
    <div style="background-color: white; padding: 20px; border-radius: 10px; 
                box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
        <h2 style="color: #4285F4; margin-bottom: 20px;">🎬 AI Video Generation (Veo)</h2>
        <p style="color: #5f6368; margin-bottom: 20px;">
            Create short videos with Google's Vertex AI Veo model. Describe what you want to see!
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)  # Add some space
    
    # Information box about video generation 
    st.info("""
    **Please Note**: Video generation with Vertex AI's Veo API is in preview. The system creates 
    short video clips based on your text description. For best results, be clear and specific with your prompts.
    
    **Veo Specifications:**
    - Duration: Variable (depends on prompt and model capabilities)
    - Resolution: High quality video generation
    - Supports text-to-video and image-to-video
    - Advanced prompt understanding
    - Rate limit: 2 videos per request maximum
    """)
    
    # Prompt input with styling
    st.markdown('<p style="font-size: 18px; font-weight: 500; margin-bottom: 10px;">What would you like to create?</p>', 
                unsafe_allow_html=True)
    
    prompt = st.text_area(
        "Describe the video you want to generate:",
        placeholder="Example: A drone camera flying over a tropical beach with palm trees swaying in the breeze and waves crashing on the shore",
        help="Be descriptive for best results. Consider including camera movement, subjects, actions, and environment.",
        height=100,
        key="veo_prompt",
        label_visibility="collapsed"
    )
    
    # Generation options
    st.markdown('<p style="font-size: 16px; font-weight: 500; margin: 15px 0 10px 0;">Video Options</p>', 
                unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        duration = st.slider("Duration (seconds):", 1, 10, 5, key="veo_duration")
    with col2:
        quality = st.select_slider(
            "Generation Quality:",
            options=["Draft", "Standard", "Premium"],
            value="Standard",
            key="veo_quality"
        )
    
    # Initialize session state for enhanced prompt display
    if "show_enhanced_video_prompt_structure" not in st.session_state:
        st.session_state.show_enhanced_video_prompt_structure = False
    if "enhanced_video_prompt_content" not in st.session_state:
        st.session_state.enhanced_video_prompt_content = None

    # Add prompt enhancement feature for video
    with st.expander("🔍 Enhance your prompt (optional)", expanded=False):
        st.markdown("""
        <p style="color: #5f6368; font-size: 14px;">
        Let AI help you enhance your prompt with more details for better video results. 
        This will add specific details about camera movement, scene composition, timing, and more.
        </p>
        """, unsafe_allow_html=True)
        
        enhance_col, _ = st.columns([1, 3])
        with enhance_col:
            enhance_button = st.button(
                "🪄 Enhance Prompt", 
                key="enhance_veo_prompt", # Keep original key
                use_container_width=True
            )
        
        if enhance_button and prompt:
            with st.spinner("Enhancing your video prompt..."):
                try:
                    # Use the agent's enhancement method
                    enhanced_prompt = chatbot_agent._enhance_video_prompt(prompt, duration)
                    
                    # Update the prompt field with the enhanced version
                    st.session_state.veo_prompt = enhanced_prompt
                    st.success("Prompt enhanced! The text area has been updated.")
                    
                    # Prepare content for the separate expander
                    sections = {}
                    current_section = None
                    if "Scene description:" in enhanced_prompt:
                        for line in enhanced_prompt.split('\\n'):
                            if ":" in line and line.split(":")[0].strip() in ["Scene description", "Camera movement", 
                                                                            "Subjects", "Actions", "Environment", 
                                                                            "Lighting", "Mood", "Timing", "Transitions"]:
                                current_section = line.split(":")[0].strip()
                                sections[current_section] = line.split(":", 1)[1].strip()
                            elif current_section and line.strip():
                                sections[current_section] += " " + line.strip()
                        st.session_state.enhanced_video_prompt_content = sections
                    else:
                        st.session_state.enhanced_video_prompt_content = enhanced_prompt
                        
                    st.session_state.show_enhanced_video_prompt_structure = True
                    st.info("To use the original prompt instead, simply edit the text area. View enhanced details below.")
                except Exception as e:
                    st.error(f"Failed to enhance prompt: {str(e)}")
                    st.session_state.show_enhanced_video_prompt_structure = False # Reset on error
        elif enhance_button and not prompt:
            st.warning("Please enter a prompt first before enhancing.")
            st.session_state.show_enhanced_video_prompt_structure = False # Reset

    # Display enhanced prompt structure if available (moved outside the above expander)
    if st.session_state.get("show_enhanced_video_prompt_structure", False):
        st.markdown("<br>", unsafe_allow_html=True)  # Add some space
        st.markdown("<h3>Enhanced Prompt Details</h3>", unsafe_allow_html=True)
        if isinstance(st.session_state.enhanced_video_prompt_content, dict):
            for section, content in st.session_state.enhanced_video_prompt_content.items():
                st.markdown(f"<strong>{section}:</strong> {content}", unsafe_allow_html=True)
        else:
            st.markdown(st.session_state.enhanced_video_prompt_content, unsafe_allow_html=True)

    # Generate button with styling
    generate_col, _ = st.columns([1, 3])
    with generate_col:
        generate_button = st.button(
            "🎥 Generate Video", 
            type="primary",
            use_container_width=True,
            key="veo_generate"
        )
    
    # Handle video generation
    if generate_button:
        if not prompt or prompt.strip() == "":
            st.error("Please enter a description for the video you want to generate.")
        else:
            # Show progress
            with st.status("Generating your video...", expanded=True) as status:
                st.write("Processing your prompt...")
                time.sleep(0.7)
                st.write("Creating scene composition...")
                time.sleep(0.8)
                st.write("Generating video frames...")
                time.sleep(1.0)
                st.write("Rendering final video...")
                time.sleep(1.2)
                
                try:
                    # Check if Vertex AI service is properly configured
                    if hasattr(vertex_service, 'initialized') and vertex_service.initialized:
                        # Call Vertex AI service through the agent
                        video_result = chatbot_agent.generate_video(
                            prompt=prompt,
                            duration=duration
                        )
                        
                        if video_result["success"]:
                            status.update(label="Video generated successfully!", state="complete")
                            
                            # Display video
                            st.markdown('<p style="font-size: 18px; font-weight: 500; margin: 20px 0 10px 0;">Generated Video</p>', 
                                       unsafe_allow_html=True)
                            
                            try:
                                # Check if we have base64 data or a video URL
                                if video_result.get("base64"):
                                    # Convert base64 to binary for display
                                    video_bytes = base64.b64decode(video_result["base64"])
                                    
                                    # Save to a temporary file for display
                                    temp_file_path = f"temp_video_{int(time.time())}.mp4"
                                    with open(temp_file_path, "wb") as f:
                                        f.write(video_bytes)
                                    
                                    # Display the video
                                    st.video(temp_file_path)
                                    
                                    # Provide download button
                                    download_data = video_bytes
                                    
                                elif video_result.get("video_url"):
                                    # Display video from URL
                                    video_url = video_result["video_url"]
                                    st.video(video_url)
                                    
                                    # For download, we'll show a message about the URL
                                    st.info(f"Video is stored at: {video_url}")
                                    st.caption("Note: This is a Google Cloud Storage URL. You may need appropriate permissions to access it directly.")
                                    
                                    # Placeholder download data
                                    download_data = video_url.encode('utf-8')
                                    temp_file_path = None
                                    
                                else:
                                    st.error("No video data or URL available in the response")
                                    return
                                
                                # Show prompts used (as simple text to avoid expander nesting)
                                st.caption(f"**Original:** {video_result['original_prompt'][:50]}{'...' if len(video_result['original_prompt']) > 50 else ''}")
                                st.caption(f"**Enhanced:** {video_result['prompt'][:50]}{'...' if len(video_result['prompt']) > 50 else ''}")
                                st.caption(f"**Duration:** {video_result['duration']} seconds")
                                
                                # Show any download errors
                                if video_result.get("download_error"):
                                    st.caption(f"**Note:** Could not download video for local access: {video_result['download_error'][:100]}{'...' if len(video_result['download_error']) > 100 else ''}")
                                
                                # Download button
                                if video_result.get("base64"):
                                    st.download_button(
                                        label="Download Video",
                                        data=download_data,
                                        file_name=f"generated_video_{int(time.time())}.mp4",
                                        mime="video/mp4"
                                    )
                                else:
                                    st.download_button(
                                        label="Download Video URL",
                                        data=download_data,
                                        file_name=f"video_url_{int(time.time())}.txt",
                                        mime="text/plain"
                                    )
                                
                                # Clean up temp file if it exists
                                if temp_file_path:
                                    try:
                                        os.remove(temp_file_path)
                                    except:
                                        pass
                                    
                            except Exception as e:
                                st.error(f"Error displaying video: {str(e)}")
                        else:
                            status.update(label=f"Error: {video_result.get('error', 'Unknown error')}", state="error")
                            st.error(f"Failed to generate video: {video_result.get('error', 'Unknown error')}")
                            
                            # Show prompt for debugging (as simple text to avoid expander nesting)
                            st.caption(f"**Original:** {video_result.get('original_prompt', 'N/A')[:50]}{'...' if len(video_result.get('original_prompt', '')) > 50 else ''}")
                            st.caption(f"**Enhanced:** {video_result.get('prompt', 'N/A')[:50]}{'...' if len(video_result.get('prompt', '')) > 50 else ''}")
                            st.caption(f"**Duration:** {video_result.get('duration', 'N/A')} seconds")
                            
                            # Show additional debugging info
                            if video_result.get('video_url'):
                                st.caption(f"**Video URL:** {video_result['video_url'][:50]}{'...' if len(video_result['video_url']) > 50 else ''}")
                            if video_result.get('base64'):
                                st.caption(f"**Has base64 data:** Yes ({len(video_result['base64'])} chars)")
                            else:
                                st.caption(f"**Has base64 data:** No")
                    else:
                        # Simulation for demo purposes
                        status.update(label="Showing sample video (Vertex AI not configured)", state="complete")
                        
                        # Display placeholder video
                        st.markdown('<p style="font-size: 18px; font-weight: 500; margin: 20px 0 10px 0;">Sample Video</p>', 
                                   unsafe_allow_html=True)
                        
                        # Sample video
                        st.video("https://www.w3schools.com/html/mov_bbb.mp4")
                        
                        st.markdown(f"<p style='font-size: 12px; color: #5f6368;'>Prompt: {prompt[:50]}{'...' if len(prompt) > 50 else ''}</p>", 
                                   unsafe_allow_html=True)
                        
                        # Download button (placeholder)
                        st.download_button(
                            label="Download Sample Video",
                            data=b"Placeholder binary data", 
                            file_name="sample_video.mp4",
                            mime="video/mp4"
                        )
                except Exception as e:
                    status.update(label=f"Error: {str(e)}", state="error")
                    st.error(f"Failed to generate video: {str(e)}")

def main():
    """Main application entry point"""
    # Set page config
    st.set_page_config(
        page_title=config.APP_NAME,
        page_icon="✨",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Apply custom theme
    st.markdown(get_custom_theme(), unsafe_allow_html=True)
    
    # Create sidebar and get selected feature
    selected_feature = create_sidebar()
    
    # Update agent mode if it changed in the sidebar
    if "agent_mode" in st.session_state:
        chatbot_agent.set_agent_mode(st.session_state.agent_mode)
    
    # Render appropriate page based on selection
    if selected_feature == "Chatbot Assistant":
        render_chatbot_page()
    elif selected_feature == "Image Generated":
        render_image_generation_page()
    elif selected_feature == "Video Generated":
        render_video_generation_page()
    
    # Agent mode info
    if "agent_mode" in st.session_state:
        current_mode = st.session_state.agent_mode
        mode_descriptions = {
            "default": "Balanced approach providing general assistance across all creative and informational tasks.",
            "creative": "Enhanced creativity mode focusing on original, artistic, and emotionally impactful content.",
            "professional": "Business-oriented mode emphasizing clarity, structure, and professional communication.",
            "educational": "Teaching mode breaking down complex topics with clear explanations and examples.",
            "technical": "Technical mode providing detailed, accurate information with implementation guidance."
        }
        
        with st.expander("ℹ️ Current AI Assistant Mode", expanded=False):
            mode_display_name = {
                "default": "Balanced Mode",
                "creative": "Creative Mode",
                "professional": "Professional Mode", 
                "educational": "Educational Mode",
                "technical": "Technical Mode"
            }.get(current_mode, "Default Mode")
            
            st.markdown(f"""
            <div style="background-color: #E8F0FE; padding: 10px; border-radius: 10px; margin-bottom: 10px;">
                <strong>Currently using:</strong> {mode_display_name}
            </div>
            <p>{mode_descriptions.get(current_mode, "")}</p>
            <p><em>Your AI responses will be tailored according to this mode. You can change the mode in the sidebar.</em></p>
            """, unsafe_allow_html=True)
    
    # Footer
    with st.container():
        st.markdown("""
        <div style="text-align: center; margin-top: 40px; padding: 20px; color: #5f6368; font-size: 12px;">
        </div>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()