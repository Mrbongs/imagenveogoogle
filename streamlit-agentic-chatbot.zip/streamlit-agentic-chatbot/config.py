import os
from dotenv import load_dotenv
import json

# Load environment variables from .env file
load_dotenv()

# Define base directory for constructing relative paths
CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))

# Google Cloud & Service Account credentials
DEFAULT_CREDENTIALS_PATH = os.path.join(os.path.dirname(CONFIG_DIR), "..", "api", "yourgemini.json")
GOOGLE_APPLICATION_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", DEFAULT_CREDENTIALS_PATH)

DEFAULT_VERTEX_PATH = os.path.join(os.path.dirname(CONFIG_DIR), "..", "api", "yourvertex.json")
VERTEX_CREDENTIALS = os.getenv("VERTEX_CREDENTIALS", DEFAULT_VERTEX_PATH)

DEFAULT_STORAGE_PATH = os.path.join(os.path.dirname(CONFIG_DIR), "..", "api", "youjsonstorage.json")
STORAGE_CREDENTIALS = os.getenv("STORAGE_CREDENTIALS", DEFAULT_STORAGE_PATH)

# Parse project ID from credentials file
try:
    with open(GOOGLE_APPLICATION_CREDENTIALS, 'r') as f:
        credentials_data = json.load(f)
        PROJECT_ID = credentials_data.get('project_id', '')
except Exception as e:
    print(f"Warning: Could not parse project_id from credentials file: {e}")
    PROJECT_ID = os.getenv("GOOGLE_PROJECT_ID", "CHANGEDEFAULT YOUR PROJECT")  # Default project ID

# Google Cloud & Vertex AI settings
REGION = os.getenv("GOOGLE_LOCATION", "us-central1")  # us-central1 is the primary region for Veo models
API_KEY = os.getenv("GEMINI_API_KEY", "YOURGOOGLEAPIGEMINI")  # Default from previous config
VERTEX_MODEL = os.getenv("VERTEX_MODEL", "imagegeneration@004")  # For Imagen
VEO_MODEL = os.getenv("VEO_MODEL", "veo-3.0-generate-preview")  # Veo 3.0 Preview model
VEO_OUTPUT_STORAGE_URI = os.getenv("VEO_OUTPUT_STORAGE_URI", "YOURPROJECT") # URI for Veo output

# Application settings
APP_NAME = "AI Media Studio"
MAX_UPLOAD_SIZE = 20 * 1024 * 1024  # 20MB
BACKEND_URL = "http://localhost:8000"
FRONTEND_PORT = 8501

# Gemini API model settings
GEMINI_MODEL = "models/gemini-2.5-pro-preview-05-06"  # Default model
GEMINI_TEMPERATURE = 0.2
GEMINI_MAX_TOKENS = 4000