# AI Media Studio

AI Media Studio is a Streamlit-based web application that leverages Google's Gemini and Vertex AI models to provide a suite of generative AI tools. Users can engage in interactive chat, generate images, and create short video clips through an intuitive interface.

## Features

-   **Interactive Chatbot:** Engage in dynamic conversations with an AI powered by Google's Gemini models.
-   **Image Generation:** Create unique images from textual descriptions using Vertex AI's image generation capabilities.
-   **Video Generation:** Produce short video clips based on textual prompts, powered by Vertex AI.
-   **Agentic Framework:** Utilizes an agent-based architecture to manage interactions with AI models.
-   **Retry Mechanisms:** Robust error handling and retry logic for API calls to ensure reliability.
-   **Downloadable Media:** Easily download generated images and videos.
-   **Configurable:** API keys and other settings can be configured via a `config.py` file.

## Project Structure

```
streamlit-agentic-chatbot/
├── agents/                     # Contains the core agent logic (e.g., ChatbotAgent)
│   └── chatbot_agent.py
├── services/                   # Modules for interacting with external AI services (Gemini, Vertex AI)
│   ├── gemini_service.py
│   └── vertex_service.py
├── ui/                         # User interface components (e.g., sidebar, page renderers)
│   ├── sidebar.py
│   └── ... (other UI files)
├── utils/                      # Utility functions and helper scripts
│   ├── helpers.py
│   └── prompt_templates.py
├── app.py                      # Main Streamlit application file
├── config.py                   # Configuration file for API keys and settings (user-created)
├── requirements.txt            # Python dependencies
├── run_app.bat                 # Batch script to set up and run the application on Windows
├── run_app.ps1                 # PowerShell script to set up and run the application on Windows
└── README.md                   # This file
```

## Setup and Installation

1.  **Clone the Repository:**
    ```bash
    git clone <repository-url>
    cd streamlit-agentic-chatbot
    ```

2.  **Create `config.py`:**
    Create a `config.py` file in the root directory of the project and add your Google API Key:
    ```python
    # config.py
    GOOGLE_API_KEY = "YOUR_GOOGLE_API_KEY"
    VERTEX_AI_PROJECT = "YOUR_VERTEX_AI_PROJECT"
    VERTEX_AI_LOCATION = "YOUR_VERTEX_AI_LOCATION"
    ```
    Replace `"YOUR_GOOGLE_API_KEY"`, `"YOUR_VERTEX_AI_PROJECT"`, and `"YOUR_VERTEX_AI_LOCATION"` with your actual credentials and project details.

3.  **Set up Virtual Environment and Install Dependencies:**
    *   **Using `run_app.bat` (Windows CMD):**
        Double-click the `run_app.bat` file. It will:
        *   Check for Python installation.
        *   Create a virtual environment named `venv`.
        *   Activate the virtual environment.
        *   Install the required packages from `requirements.txt`.
        *   Run the Streamlit application.

    *   **Using `run_app.ps1` (Windows PowerShell):**
        Open PowerShell, navigate to the project directory, and run:
        ```powershell
        .\run_app.ps1
        ```
        This script performs the same setup steps as the batch file.
        *Note: You might need to adjust your PowerShell execution policy by running `Set-ExecutionPolicy Unrestricted -Scope Process` if you encounter issues running the script.*

    *   **Manual Setup:**
        If you prefer manual setup:
        ```bash
        # Create a virtual environment
        python -m venv venv

        # Activate the virtual environment
        # On Windows:
        venv\Scripts\activate
        # On macOS/Linux:
        source venv/bin/activate

        # Install dependencies
        pip install -r requirements.txt
        ```

4.  **Run the Application:**
    If you used the scripts, the application should already be running. For manual startup:
    ```bash
    streamlit run app.py
    ```

## Usage

Once the application is running, open your web browser and navigate to the local URL provided by Streamlit (usually `http://localhost:8501`).

-   **Chat:** Select "Chat" from the sidebar to interact with the AI chatbot.
-   **Image Generation:** Select "Image Generation" to create images from text prompts.
-   **Video Generation:** Select "Video Generation" to create videos from text prompts.

## Dependencies

The main dependencies are listed in `requirements.txt` and include:
-   `streamlit`
-   `google-generativeai`
-   `google-cloud-aiplatform`
-   `tenacity`
-   `Pillow`
-   And others for UI enhancements and utility.

## Contributing

Contributions are welcome! Please fork the repository and submit a pull request with your changes.

## License

This project is licensed under the MIT License - see the LICENSE file for details (if applicable, otherwise state "Not licensed" or choose an appropriate open-source license).